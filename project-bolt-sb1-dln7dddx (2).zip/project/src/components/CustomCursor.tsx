import { useEffect, useRef, useState } from 'react'
import { motion, useMotionValue, useSpring } from 'framer-motion'

type CursorMode = 'default' | 'link' | 'cta' | 'view' | 'drag' | 'text'

export function CustomCursor() {
  const x = useMotionValue(-100)
  const y = useMotionValue(-100)
  const sx = useSpring(x, { stiffness: 500, damping: 40, mass: 0.3 })
  const sy = useSpring(y, { stiffness: 500, damping: 40, mass: 0.3 })
  const [mode, setMode] = useState<CursorMode>('default')
  const [visible, setVisible] = useState(false)
  const rafRef = useRef(0)

  useEffect(() => {
    if (window.matchMedia('(pointer: coarse)').matches) return // touch device
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return

    const onMove = (e: MouseEvent) => {
      x.set(e.clientX)
      y.set(e.clientY)
      if (!visible) setVisible(true)
      const el = e.target as HTMLElement
      const tagged = el.closest('[data-cursor]') as HTMLElement | null
      setMode((tagged?.dataset.cursor as CursorMode) || 'default')
    }
    const onLeave = () => setVisible(false)
    const onDown = () => setMode((m) => (m === 'default' ? 'default' : m))
    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseout', onLeave)
    window.addEventListener('mousedown', onDown)
    return () => {
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseout', onLeave)
      window.removeEventListener('mousedown', onDown)
      cancelAnimationFrame(rafRef.current)
    }
  }, [x, y, visible])

  const sizes: Record<CursorMode, number> = {
    default: 14, link: 36, cta: 48, view: 56, drag: 44, text: 6,
  }
  const labels: Partial<Record<CursorMode, string>> = {
    cta: 'ENGAGE', view: 'VIEW', drag: 'DRAG',
  }

  return (
    <motion.div
      className="pointer-events-none fixed top-0 left-0 z-[200] flex items-center justify-center"
      style={{ x: sx, y: sy }}
      animate={{ opacity: visible ? 1 : 0 }}
      transition={{ duration: 0.2 }}
    >
      <motion.div
        className="flex items-center justify-center rounded-full border border-cyan/50 bg-cyan/5 backdrop-blur-sm"
        animate={{
          width: sizes[mode],
          height: sizes[mode],
          backgroundColor: mode === 'default' ? 'rgba(34,211,238,0.05)' : 'rgba(34,211,238,0.12)',
        }}
        transition={{ type: 'spring', stiffness: 300, damping: 22 }}
      >
        {labels[mode] && (
          <span className="font-mono text-[8px] uppercase tracking-[0.2em] text-cyan">
            {labels[mode]}
          </span>
        )}
      </motion.div>
    </motion.div>
  )
}
