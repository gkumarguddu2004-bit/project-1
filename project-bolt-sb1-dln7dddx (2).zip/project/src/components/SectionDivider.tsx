import { cn } from '@/lib/cn'

export function SectionDivider({ className, label }: { className?: string; label?: string }) {
  return (
    <div className={cn('flex items-center gap-4 py-2', className)}>
      <div className="h-px flex-1 bg-gradient-to-r from-transparent via-cyan/20 to-transparent" />
      {label && <span className="font-mono text-[10px] uppercase tracking-[0.4em] text-ink-400">{label}</span>}
      <div className="h-px flex-1 bg-gradient-to-r from-transparent via-cyan/20 to-transparent" />
    </div>
  )
}
