import { cn } from '@/lib/cn'

type IconName =
  | 'neural' | 'grid' | 'ripple' | 'graph' | 'shield' | 'loop' | 'server' | 'bolt'
  | 'lock' | 'gear' | 'wave' | 'chart' | 'layers' | 'spark' | 'heart' | 'check'
  | 'arrow-right' | 'arrow-up-right' | 'close' | 'quote' | 'dot' | 'logo'
  | 'crack' | 'send' | 'mic' | 'brain' | 'activity'

const paths: Record<IconName, React.ReactNode> = {
  neural: <><circle cx="12" cy="6" r="2" /><circle cx="6" cy="18" r="2" /><circle cx="18" cy="18" r="2" /><circle cx="12" cy="12" r="1.6" /><path d="M12 8v2.4M10.4 13.6 7.4 16.4M13.6 13.6l3 2.8" /></>,
  grid: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
  ripple: <><path d="M3 12c3-4 6-4 9 0s6 4 9 0" /><path d="M3 17c3-4 6-4 9 0s6 4 9 0" opacity="0.5" /><path d="M3 7c3-4 6-4 9 0s6 4 9 0" opacity="0.5" /></>,
  graph: <><path d="M4 19V5M4 19h16" /><path d="M7 16l3-4 3 2 5-7" /></>,
  shield: <><path d="M12 3l7 3v5c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3z" /><path d="M9 12l2 2 4-4" /></>,
  loop: <><path d="M5 12a7 7 0 0 1 12-5l2 2" /><path d="M19 12a7 7 0 0 1-12 5l-2-2" /><path d="M19 5v4h-4M5 19v-4h4" /></>,
  server: <><rect x="4" y="4" width="16" height="6" rx="1.5" /><rect x="4" y="14" width="16" height="6" rx="1.5" /><circle cx="8" cy="7" r="1" /><circle cx="8" cy="17" r="1" /></>,
  bolt: <path d="M13 3L4 14h6l-1 7 9-11h-6l1-7z" />,
  lock: <><rect x="5" y="11" width="14" height="9" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></>,
  gear: <><circle cx="12" cy="12" r="3" /><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2" /></>,
  wave: <><path d="M3 12c2-3 4-3 6 0s4 3 6 0 4-3 6 0" /><path d="M3 17c2-3 4-3 6 0s4 3 6 0 4-3 6 0" opacity="0.4" /></>,
  chart: <><path d="M4 19V5M4 19h16" /><rect x="7" y="11" width="2.5" height="6" /><rect x="11" y="8" width="2.5" height="9" /><rect x="15" y="13" width="2.5" height="4" /></>,
  layers: <><path d="M12 3l9 5-9 5-9-5 9-5z" /><path d="M3 13l9 5 9-5" opacity="0.5" /></>,
  spark: <path d="M12 3v6M12 15v6M3 12h6M15 12h6M6 6l3 3M15 15l3 3M18 6l-3 3M9 15l-3 3" />,
  heart: <path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10z" />,
  check: <path d="M5 12l5 5L19 7" />,
  'arrow-right': <><path d="M5 12h14M13 6l6 6-6 6" /></>,
  'arrow-up-right': <><path d="M7 17L17 7M9 7h8v8" /></>,
  close: <><path d="M6 6l12 12M18 6L6 18" /></>,
  quote: <><path d="M7 7h4v4c0 2-1 3-3 3M13 7h4v4c0 2-1 3-3 3" /></>,
  dot: <circle cx="12" cy="12" r="3" />,
  logo: <><path d="M12 2l9 5v10l-9 5-9-5V7l9-5z" /><path d="M12 7v10M7 9.5v5M17 9.5v5" opacity="0.6" /></>,
  crack: <><path d="M12 3l2 6-3 4 4 5-3 3" /><path d="M6 8l3 2M18 9l-3 1" opacity="0.5" /></>,
  send: <><path d="M4 12l16-8-6 16-3-7-7-1z" /></>,
  mic: <><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" /></>,
  brain: <><path d="M9 4a3 3 0 0 0-3 3v1a3 3 0 0 0-1 5 3 3 0 0 0 4 4V4z" /><path d="M15 4a3 3 0 0 1 3 3v1a3 3 0 0 1 1 5 3 3 0 0 1-4 4V4z" /></>,
  activity: <path d="M3 12h4l3-7 4 14 3-7h4" />,
}

export type { IconName }

export function Icon({
  name,
  className,
  size = 24,
  strokeWidth = 1.6,
  fill = 'none',
}: {
  name: IconName
  className?: string
  size?: number
  strokeWidth?: number
  fill?: 'none' | 'currentColor'
}) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={fill}
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={cn('shrink-0', className)}
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  )
}
