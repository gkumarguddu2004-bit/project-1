import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Icon } from './Icon'
import { createScramble } from '@/lib/scramble'

const BOOT_LOG = [
  '> initializing spatial runtime...',
  '> mounting quantum grid shader...',
  '> calibrating navier-stokes fluid solver...',
  '> linking fresnel glass + chromatic aberration...',
  '> spinning up magnetic cursor engine...',
  '> activating 60fps guardrail...',
  '> system online.',
]

export function BootSequence({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0)
  const [logIndex, setLogIndex] = useState(0)
  const [scramble, setScramble] = useState('')
  const [done, setDone] = useState(false)

  useEffect(() => {
    const target = 'GK WEBER · SPATIAL AI OS'
    const stop = createScramble(target, setScramble, undefined, 1400, 28)
    return stop
  }, [])

  useEffect(() => {
    if (progress >= 100) {
      const t = setTimeout(() => setDone(true), 600)
      return () => clearTimeout(t)
    }
    const step = setInterval(() => {
      setProgress((p) => Math.min(100, p + Math.random() * 8 + 3))
    }, 80)
    return () => clearInterval(step)
  }, [progress])

  useEffect(() => {
    const idx = Math.min(BOOT_LOG.length - 1, Math.floor((progress / 100) * BOOT_LOG.length))
    setLogIndex(idx)
  }, [progress])

  useEffect(() => {
    if (!done) return
    const t = setTimeout(onComplete, 500)
    return () => clearTimeout(t)
  }, [done, onComplete])

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          className="fixed inset-0 z-[100] bg-ink-950 flex flex-col items-center justify-center px-6"
          exit={{ opacity: 0, scale: 1.04 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="absolute inset-0 grid-bg opacity-40" />
          <div className="absolute inset-0 spotlight opacity-60" />

          <motion.div
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="relative z-10 flex flex-col items-center"
          >
            <div className="relative mb-8">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
                className="absolute inset-0 -m-6"
              >
                <div className="absolute inset-0 rounded-full border border-cyan/20" />
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-cyan shadow-[0_0_12px_rgba(34,211,238,0.8)]" />
              </motion.div>
              <Icon name="logo" size={56} className="text-cyan" />
            </div>

            <h1 className="font-display text-2xl sm:text-3xl font-semibold tracking-tightest text-ink-100 mb-1">
              {scramble}
            </h1>
            <p className="font-mono text-[10px] uppercase tracking-[0.4em] text-ink-400 mb-8">
              Quantum-Cinematic Runtime v10.0
            </p>

            <div className="w-72 sm:w-96 h-1 rounded-full bg-ink-800 overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-cyan to-cyan-glow"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="flex items-center justify-between w-72 sm:w-96 mt-2 font-mono text-[10px] text-ink-400">
              <span>{Math.round(progress)}%</span>
              <span className="text-cyan/70">LOADING</span>
            </div>

            <div className="mt-8 h-5 font-mono text-xs text-cyan/60 text-center">
              {BOOT_LOG[logIndex]}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
