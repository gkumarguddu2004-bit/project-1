import { motion } from 'framer-motion'
import { Icon } from './Icon'

export function Hero() {
  return (
    <section id="top" className="relative min-h-screen flex items-center justify-center px-5 pt-20 pb-12 scene preserve-3d">
      <div className="relative z-10 max-w-5xl mx-auto text-center preserve-3d">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="inline-flex items-center gap-2 chip mb-6 depth-1"
          data-cursor="link"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-accent-emerald animate-pulse-soft" />
          <span className="font-mono text-[11px] tracking-[0.3em] uppercase">Spatial AI Operating System</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="text-4xl sm:text-6xl md:text-7xl font-semibold leading-[1.05] tracking-ultra-tight depth-2"
        >
          <span className="text-ink-100">Engineering the</span>
          <br />
          <span className="text-gradient-cyan text-shadow-glow">Digital Operating Systems</span>
          <br />
          <span className="text-ink-100">of Tomorrow</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.24, ease: [0.22, 1, 0.36, 1] }}
          className="mt-7 max-w-2xl mx-auto text-base sm:text-lg text-ink-300 leading-relaxed depth-1"
        >
          GK WEBER architects enterprise systems, AI automation pipelines, and spatial interfaces engineered for measurable business growth — not vanity metrics.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.36, ease: [0.22, 1, 0.36, 1] }}
          className="mt-9 flex flex-wrap items-center justify-center gap-3 depth-2"
        >
          <a href="#chapter-12" data-cursor="cta" className="btn-primary">
            <Icon name="arrow-up-right" size={18} /> Explore Portfolio
          </a>
          <a href="#chapter-14" data-cursor="cta" className="btn-ghost">
            <Icon name="brain" size={18} /> Launch AI Console
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="mt-14 flex items-center justify-center gap-6 font-mono text-[10px] uppercase tracking-[0.3em] text-ink-400"
        >
          <span className="flex items-center gap-1.5"><Icon name="shield" size={14} className="text-cyan/60" /> Zero-Trust</span>
          <span className="flex items-center gap-1.5"><Icon name="bolt" size={14} className="text-cyan/60" /> Edge-Native</span>
          <span className="flex items-center gap-1.5"><Icon name="neural" size={14} className="text-cyan/60" /> AI-First</span>
        </motion.div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          className="flex flex-col items-center gap-2 text-ink-400"
        >
          <span className="font-mono text-[10px] tracking-[0.3em] uppercase">Scroll</span>
          <div className="w-px h-10 bg-gradient-to-b from-cyan/40 to-transparent" />
        </motion.div>
      </div>
    </section>
  )
}
