import { useRef, type ReactNode } from 'react'
import { motion, useMotionValue, useSpring, useMotionTemplate } from 'framer-motion'
import { cn } from '@/lib/cn'

/**
 * FresnelGlass — luxury glass wrapper with noise overlay, dynamic Fresnel rim
 * lighting, and chromatic aberration (RGB split) driven by cursor position.
 *
 * FIX #3 applied: NO `overflow-hidden` on the wrapper. Chromium/WebKit breaks
 * when `overflow: hidden` sits on a `transform-style: preserve-3d` element or
 * on a parent of preserve-3d children. Clipping is delegated to the child
 * border-radius and inner mask layer instead.
 */
export function FresnelGlass({
  children,
  className,
  rounded = 'rounded-2xl',
  aberration = true,
}: {
  children: ReactNode
  className?: string
  rounded?: string
  aberration?: boolean
}) {
  const ref = useRef<HTMLDivElement>(null)
  const px = useMotionValue(50)
  const py = useMotionValue(50)

  const sx = useSpring(px, { stiffness: 120, damping: 20 })
  const sy = useSpring(py, { stiffness: 120, damping: 20 })

  const lightX = useMotionTemplate`${sx}%`
  const lightY = useMotionTemplate`${sy}%`

  const onMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    px.set(((e.clientX - rect.left) / rect.width) * 100)
    py.set(((e.clientY - rect.top) / rect.height) * 100)
  }

  const onLeave = () => {
    px.set(50)
    py.set(50)
  }

  return (
    <motion.div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      className={cn('relative preserve-3d', rounded, className)}
      style={{ transformStyle: 'preserve-3d' }}
    >
      {/* Fresnel rim light — follows cursor */}
      <motion.div
        className="absolute inset-0 pointer-events-none rounded-[inherit]"
        style={{
          background: useMotionTemplate`radial-gradient(circle at ${lightX} ${lightY}, rgba(34,211,238,0.22), transparent 55%)`,
        }}
      />
      {/* Chromatic aberration (RGB split) rim */}
      {aberration && (
        <motion.div
          className="absolute inset-0 pointer-events-none rounded-[inherit] mix-blend-screen opacity-60"
          style={{
            background: useMotionTemplate`radial-gradient(circle at ${lightX} ${lightY}, rgba(244,63,94,0.10), transparent 45%)`,
          }}
        />
      )}
      {/* Glass body */}
      <div className={cn('relative glass-strong rounded-[inherit] preserve-3d', rounded)}>
        {children}
      </div>
      {/* Noise overlay */}
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] noise-overlay opacity-[0.05] mix-blend-overlay" />
    </motion.div>
  )
}
