import { Icon } from './Icon'

export function Footer() {
  return (
    <footer className="relative z-10 border-t border-white/[0.06] bg-ink-950/60 backdrop-blur-xl">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-14">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5 mb-4">
              <Icon name="logo" size={28} className="text-cyan" />
              <span className="font-display font-semibold tracking-tightest text-lg">
                GK <span className="text-cyan">WEBER</span>
              </span>
            </div>
            <p className="text-sm text-ink-300 max-w-md leading-relaxed">
              Enterprise systems architecture, AI automation, and spatial digital operating systems engineered for measurable business growth.
            </p>
          </div>
          <div>
            <h4 className="font-mono text-[10px] uppercase tracking-[0.3em] text-ink-400 mb-4">Chapters</h4>
            <ul className="space-y-2.5 text-sm">
              <li><a href="#chapter-11" className="text-ink-300 hover:text-cyan transition-colors">Why GK WEBER</a></li>
              <li><a href="#chapter-12" className="text-ink-300 hover:text-cyan transition-colors">Portfolio</a></li>
              <li><a href="#chapter-13" className="text-ink-300 hover:text-cyan transition-colors">Business Results</a></li>
              <li><a href="#chapter-14" className="text-ink-300 hover:text-cyan transition-colors">AI Agent Suite</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-mono text-[10px] uppercase tracking-[0.3em] text-ink-400 mb-4">Standards</h4>
            <ul className="space-y-2.5 text-sm text-ink-300">
              <li className="flex items-center gap-2"><Icon name="shield" size={14} className="text-cyan/60" /> OWASP Hardened</li>
              <li className="flex items-center gap-2"><Icon name="lock" size={14} className="text-cyan/60" /> Zero-Trust Verified</li>
              <li className="flex items-center gap-2"><Icon name="bolt" size={14} className="text-cyan/60" /> Edge-Native</li>
              <li className="flex items-center gap-2"><Icon name="activity" size={14} className="text-cyan/60" /> Self-Healing Telemetry</li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-6 border-t border-white/[0.05] flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-mono text-[11px] text-ink-400">© {new Date().getFullYear()} GK WEBER. All systems operational.</p>
          <p className="font-mono text-[11px] text-ink-400">Spatial AI Operating System · v10.0</p>
        </div>
      </div>
    </footer>
  )
}
