import { useMemo } from 'react'

export function BackgroundAtmosphere() {
  const spots = useMemo(
    () => [
      { left: '8%', top: '12%', size: 520, hue: 34, delay: 0 },
      { left: '62%', top: '6%', size: 640, hue: 188, delay: 4 },
      { left: '78%', top: '58%', size: 480, hue: 200, delay: 8 },
      { left: '18%', top: '72%', size: 560, hue: 32, delay: 12 },
    ],
    []
  )
  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-60" />
      {spots.map((s, i) => (
        <div
          key={i}
          className="absolute rounded-full"
          style={{
            left: s.left,
            top: s.top,
            width: s.size,
            height: s.size,
            background: `radial-gradient(circle, hsla(${s.hue},90%,55%,0.10), transparent 65%)`,
            filter: 'blur(40px)',
            animation: `pulseSoft 8s ease-in-out ${s.delay}s infinite`,
          }}
        />
      ))}
      <div className="absolute inset-0 noise-overlay opacity-[0.04] mix-blend-overlay" />
      <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-ink-950 to-transparent" />
    </div>
  )
}
