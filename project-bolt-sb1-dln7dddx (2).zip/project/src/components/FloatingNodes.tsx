import { useEffect, useRef } from 'react'
import { motion, useMotionValue, useSpring, useTransform, type MotionValue } from 'framer-motion'

interface NodeSpec {
  id: number
  shape: 'shard' | 'cube' | 'ring' | 'node'
  size: number
  left: string
  top: string
  depth: number
  drift: 'drift' | 'drift-rev'
  duration: number
}

const NODES: NodeSpec[] = [
  { id: 1, shape: 'shard', size: 88, left: '6%', top: '18%', depth: 60, drift: 'drift', duration: 18 },
  { id: 2, shape: 'cube', size: 64, left: '88%', top: '24%', depth: 40, drift: 'drift-rev', duration: 22 },
  { id: 3, shape: 'ring', size: 120, left: '14%', top: '62%', depth: 80, drift: 'drift-rev', duration: 26 },
  { id: 4, shape: 'node', size: 48, left: '72%', top: '70%', depth: 30, drift: 'drift', duration: 20 },
  { id: 5, shape: 'shard', size: 56, left: '46%', top: '10%', depth: 50, drift: 'drift', duration: 24 },
  { id: 6, shape: 'ring', size: 72, left: '32%', top: '82%', depth: 36, drift: 'drift-rev', duration: 30 },
  { id: 7, shape: 'cube', size: 40, left: '58%', top: '44%', depth: 24, drift: 'drift', duration: 16 },
  { id: 8, shape: 'node', size: 36, left: '92%', top: '52%', depth: 44, drift: 'drift-rev', duration: 28 },
]

function Shape({ shape, size }: { shape: NodeSpec['shape']; size: number }) {
  const common = 'border-cyan/25 text-cyan/30'
  if (shape === 'shard')
    return (
      <svg width={size} height={size} viewBox="0 0 100 100" className={common} fill="none">
        <polygon points="50,5 95,40 70,95 20,75" stroke="currentColor" strokeWidth="1.2" />
        <polygon points="50,5 70,75 20,75" stroke="currentColor" strokeWidth="0.6" opacity="0.5" />
      </svg>
    )
  if (shape === 'cube')
    return (
      <svg width={size} height={size} viewBox="0 0 100 100" className={common} fill="none">
        <path d="M20 30L50 12L80 30L50 48z" stroke="currentColor" strokeWidth="1.2" />
        <path d="M80 30v40L50 88V48" stroke="currentColor" strokeWidth="1.2" />
        <path d="M20 30v40L50 88" stroke="currentColor" strokeWidth="1.2" />
      </svg>
    )
  if (shape === 'ring')
    return (
      <svg width={size} height={size} viewBox="0 0 100 100" className={common} fill="none">
        <circle cx="50" cy="50" r="40" stroke="currentColor" strokeWidth="1.2" />
        <circle cx="50" cy="50" r="28" stroke="currentColor" strokeWidth="0.6" opacity="0.5" />
        <circle cx="50" cy="50" r="3" fill="currentColor" />
      </svg>
    )
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" className={common} fill="none">
      <rect x="30" y="30" width="40" height="40" rx="6" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="50" cy="50" r="8" fill="currentColor" opacity="0.4" />
    </svg>
  )
}

function Node({ spec, mx, my }: { spec: NodeSpec; mx: MotionValue<number>; my: MotionValue<number> }) {
  const sx = useSpring(useTransform(mx, (v) => v * (spec.depth / 60)), { stiffness: 40, damping: 18 })
  const sy = useSpring(useTransform(my, (v) => v * (spec.depth / 60)), { stiffness: 40, damping: 18 })
  return (
    <motion.div
      className="absolute preserve-3d"
      style={{ left: spec.left, top: spec.top, x: sx, y: sy, translateZ: spec.depth }}
    >
      <div style={{ animation: `${spec.drift} ${spec.duration}s ease-in-out infinite` }}>
        <Shape shape={spec.shape} size={spec.size} />
      </div>
    </motion.div>
  )
}

export function FloatingNodes() {
  const mx = useMotionValue(0)
  const my = useMotionValue(0)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      mx.set((e.clientX / window.innerWidth - 0.5) * 40)
      my.set((e.clientY / window.innerHeight - 0.5) * 40)
    }
    window.addEventListener('mousemove', onMove)
    return () => window.removeEventListener('mousemove', onMove)
  }, [mx, my])

  return (
    <div ref={ref} className="pointer-events-none fixed inset-0 z-0 scene preserve-3d" aria-hidden="true">
      {NODES.map((n) => (
        <Node key={n.id} spec={n} mx={mx} my={my} />
      ))}
    </div>
  )
}
