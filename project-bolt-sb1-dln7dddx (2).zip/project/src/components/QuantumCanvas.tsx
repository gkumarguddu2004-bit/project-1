import { useEffect, useRef } from 'react'

/**
 * QuantumCanvas — Canvas2D particle fluid with 4 layers:
 *  1. Topography wipe (gradient clear)
 *  2. Noise grid (quantum field)
 *  3. Blueprint grid lines
 *  4. Particle fluid (cursor-acceleration driven)
 *
 * FIX #2 applied: strict null check on getContext('2d'); RAF loop breaks
 * immediately if canvas or context becomes null. FPS guardrail throttles
 * particleMultiplier to 0.6 when fps < 55.
 */
export function QuantumCanvas({ className }: { className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return // FIX #2: strict null check — abort if context unavailable

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    let dpr = Math.min(window.devicePixelRatio || 1, 2)
    let w = 0
    let h = 0

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      w = canvas.clientWidth
      h = canvas.clientHeight
      if (w === 0 || h === 0) return
      canvas.width = w * dpr
      canvas.height = h * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()

    const ro = new ResizeObserver(resize)
    ro.observe(canvas)

    // Mouse state
    let mx = w / 2
    let my = h / 2
    let pmx = mx
    let pmy = my
    let mouseSpeed = 0

    const onMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      pmx = mx
      pmy = my
      mx = e.clientX - rect.left
      my = e.clientY - rect.top
    }
    window.addEventListener('mousemove', onMove)

    // Particle pool
    interface P { x: number; y: number; vx: number; vy: number; life: number; max: number; r: number }
    const baseCount = reduceMotion ? 40 : 120
    const particles: P[] = []
    const spawn = (x: number, y: number, speed: number) => {
      const count = Math.min(4, Math.floor(speed * 0.4))
      for (let i = 0; i < count; i++) {
        const ang = Math.random() * Math.PI * 2
        const sp = Math.random() * speed * 0.3 + 0.4
        particles.push({
          x, y,
          vx: Math.cos(ang) * sp,
          vy: Math.sin(ang) * sp,
          life: 0,
          max: 60 + Math.random() * 60,
          r: Math.random() * 1.6 + 0.6,
        })
      }
      if (particles.length > baseCount * 2) particles.splice(0, particles.length - baseCount * 2)
    }

    // FPS guardrail
    let lastTime = performance.now()
    let frameCount = 0
    let fpsAccum = 0
    let particleMultiplier = 1

    let rafId = 0
    const render = (now: number) => {
      // FIX #2: break RAF immediately if canvas/context lost
      if (!canvas || !ctx) return
      if (w === 0 || h === 0) { rafId = requestAnimationFrame(render); return }

      const dt = now - lastTime
      lastTime = now
      frameCount++
      fpsAccum += dt
      if (fpsAccum > 500) {
        const fps = 1000 / (fpsAccum / frameCount)
        // FPS guardrail: throttle when below 55
        particleMultiplier = fps < 55 ? 0.6 : 1
        fpsAccum = 0
        frameCount = 0
      }

      // mouse acceleration
      const dx = mx - pmx
      const dy = my - pmy
      mouseSpeed = Math.min(Math.hypot(dx, dy), 40)
      pmx = mx
      pmy = my

      // Layer 1 — topography wipe
      const grad = ctx.createLinearGradient(0, 0, 0, h)
      grad.addColorStop(0, 'rgba(4,7,13,0.18)')
      grad.addColorStop(1, 'rgba(4,7,13,0.28)')
      ctx.fillStyle = grad
      ctx.fillRect(0, 0, w, h)

      // Layer 2 — noise grid (quantum field)
      ctx.fillStyle = 'rgba(34,211,238,0.018)'
      const gridSize = 40
      for (let gx = 0; gx < w; gx += gridSize) {
        for (let gy = 0; gy < h; gy += gridSize) {
          const d = Math.hypot(gx - mx, gy - my)
          const a = Math.max(0, 1 - d / 200) * 0.04
          ctx.fillStyle = `rgba(34,211,238,${a})`
          ctx.fillRect(gx, gy, 1.5, 1.5)
        }
      }

      // Layer 3 — blueprint grid lines
      ctx.strokeStyle = 'rgba(34,211,238,0.04)'
      ctx.lineWidth = 1
      ctx.beginPath()
      for (let gx = 0; gx <= w; gx += gridSize) {
        ctx.moveTo(gx, 0)
        ctx.lineTo(gx, h)
      }
      for (let gy = 0; gy <= h; gy += gridSize) {
        ctx.moveTo(0, gy)
        ctx.lineTo(w, gy)
      }
      ctx.stroke()

      // Spawn particles near cursor
      if (mouseSpeed > 0.5 && !reduceMotion) {
        spawn(mx, my, mouseSpeed * particleMultiplier)
      }

      // Layer 4 — particle fluid
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i]
        p.life++
        p.x += p.vx
        p.y += p.vy
        p.vx *= 0.96
        p.vy *= 0.96
        p.vy += 0.02 // gentle gravity
        const t = p.life / p.max
        if (t >= 1) { particles.splice(i, 1); continue }
        const alpha = (1 - t) * 0.7
        const radius = p.r * (1 - t * 0.3)
        // core
        ctx.beginPath()
        ctx.arc(p.x, p.y, radius, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(34,211,238,${alpha})`
        ctx.fill()
        // halo
        ctx.beginPath()
        ctx.arc(p.x, p.y, radius * 2.5, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(103,232,249,${alpha * 0.15})`
        ctx.fill()
      }

      rafId = requestAnimationFrame(render)
    }
    rafId = requestAnimationFrame(render)

    return () => {
      cancelAnimationFrame(rafId)
      ro.disconnect()
      window.removeEventListener('mousemove', onMove)
    }
  }, [])

  return <canvas ref={canvasRef} className={className} aria-hidden="true" />
}
