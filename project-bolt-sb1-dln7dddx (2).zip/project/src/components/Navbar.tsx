import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Icon } from './Icon'
import { cn } from '@/lib/cn'

const LINKS = [
  { label: 'Why GK WEBER', href: '#chapter-11' },
  { label: 'Portfolio', href: '#chapter-12' },
  { label: 'Business Results', href: '#chapter-13' },
  { label: 'AI Agent Suite', href: '#chapter-14' },
]

export function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        'fixed top-0 inset-x-0 z-50 transition-all duration-500',
        scrolled ? 'bg-ink-950/80 backdrop-blur-xl border-b border-white/[0.06]' : 'bg-transparent'
      )}
    >
      <nav className="mx-auto max-w-7xl px-5 sm:px-8 h-16 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2.5 group" data-cursor="link">
          <Icon name="logo" size={28} className="text-cyan transition-transform group-hover:rotate-12" />
          <span className="font-display font-semibold tracking-tightest text-ink-100">
            GK <span className="text-cyan">WEBER</span>
          </span>
        </a>
        <ul className="hidden md:flex items-center gap-1">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                data-cursor="link"
                className="px-3.5 py-2 rounded-lg text-sm text-ink-300 hover:text-cyan transition-colors duration-300"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>
        <div className="hidden md:flex items-center gap-3">
          <a href="#chapter-14" data-cursor="cta" className="btn-primary text-sm py-2.5">
            <Icon name="send" size={16} /> Engage System
          </a>
        </div>
        <button
          className="md:hidden p-2 text-ink-200"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          <Icon name={open ? 'close' : 'grid'} size={22} />
        </button>
      </nav>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden bg-ink-950/95 backdrop-blur-xl border-b border-white/[0.06]"
          >
            <ul className="px-5 py-4 space-y-1">
              {LINKS.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    onClick={() => setOpen(false)}
                    className="block px-3 py-2.5 rounded-lg text-ink-200 hover:text-cyan hover:bg-white/[0.03]"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
              <li>
                <a href="#chapter-14" onClick={() => setOpen(false)} className="btn-primary w-full justify-center mt-2 text-sm">
                  <Icon name="send" size={16} /> Engage System
                </a>
              </li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  )
}
