import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { workflowVerticals } from '@/data/chapter11'
import { Icon } from '@/components/Icon'
import { cn } from '@/lib/cn'

const PIPE_SECTORS = [
  { id: 'ingest', label: 'Ingest', icon: 'server' as const },
  { id: 'process', label: 'Process', icon: 'gear' as const },
  { id: 'infer', label: 'Infer', icon: 'neural' as const },
  { id: 'dispatch', label: 'Dispatch', icon: 'loop' as const },
  { id: 'telemetry', label: 'Telemetry', icon: 'activity' as const },
]

export function PipelineVisualizer() {
  const [active, setActive] = useState(0)
  const [vertical, setVertical] = useState(0)

  const current = workflowVerticals[vertical]

  return (
    <div className="glass-strong rounded-2xl p-6 sm:p-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <p className="section-eyebrow mb-2">3D Matrix Pipeline</p>
          <h3 className="text-xl font-semibold text-ink-100">Live System Flow Visualizer</h3>
        </div>
        <div className="flex gap-2">
          {workflowVerticals.map((v, i) => (
            <button
              key={v.id}
              onClick={() => setVertical(i)}
              data-cursor="link"
              className={cn(
                'px-3 py-1.5 rounded-lg text-xs font-mono uppercase tracking-wider transition-all',
                i === vertical
                  ? 'bg-cyan/15 text-cyan border border-cyan/30'
                  : 'text-ink-400 hover:text-ink-200 border border-transparent'
              )}
            >
              {v.label}
            </button>
          ))}
        </div>
      </div>

      {/* Pipeline grid */}
      <div className="relative scene preserve-3d">
        <div
          className="relative grid grid-cols-5 gap-2 sm:gap-4 preserve-3d"
          style={{ transform: 'perspective(900px) rotateX(20deg) rotateY(-8deg)' }}
        >
          {PIPE_SECTORS.map((sector, i) => (
            <button
              key={sector.id}
              onClick={() => setActive(i)}
              data-cursor="link"
              className={cn(
                'relative preserve-3d rounded-xl p-3 sm:p-4 text-center transition-all duration-300 border',
                i === active
                  ? 'crystal-glass border-cyan/40'
                  : 'glass border-white/[0.06] hover:border-cyan/20'
              )}
              style={{ transform: `translateZ(${i === active ? 30 : 10}px)` }}
            >
              <Icon
                name={sector.icon}
                size={20}
                className={cn('mx-auto mb-2', i === active ? 'text-cyan' : 'text-ink-400')}
              />
              <span className={cn('text-[10px] sm:text-xs font-mono uppercase tracking-wider', i === active ? 'text-cyan' : 'text-ink-300')}>
                {sector.label}
              </span>
              {/* Neon pipe connector */}
              {i < PIPE_SECTORS.length - 1 && (
                <div className="hidden sm:block absolute top-1/2 -right-2 w-2 h-px neon-pipe-dim" />
              )}
            </button>
          ))}

          {/* Traveling orb */}
          <motion.div
            className="absolute top-1/2 w-3 h-3 rounded-full bg-cyan shadow-[0_0_16px_rgba(34,211,238,0.9)] pointer-events-none"
            style={{ y: '-50%' }}
            animate={{ left: `calc(${(active / (PIPE_SECTORS.length - 1)) * 100}% - 6px)` }}
            transition={{ type: 'spring', stiffness: 120, damping: 16 }}
          />
        </div>
      </div>

      {/* Detail panel */}
      <AnimatePresence mode="wait">
        <motion.div
          key={`${vertical}-${active}`}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className="mt-6 grid sm:grid-cols-2 gap-4"
        >
          <div className="rounded-xl bg-accent-rose/5 border border-accent-rose/15 p-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent-rose/70 mb-2">Legacy</p>
            <p className="text-sm text-ink-300">{current.legacy[active] || current.legacy[0]}</p>
          </div>
          <div className="rounded-xl bg-cyan/5 border border-cyan/20 p-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-cyan/70 mb-2">GK WEBER</p>
            <p className="text-sm text-ink-100">{current.optimized[active] || current.optimized[0]}</p>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
