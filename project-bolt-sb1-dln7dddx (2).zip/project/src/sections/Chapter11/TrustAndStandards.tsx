import { enterpriseStandards, clientPromise, capabilityMetrics } from '@/data/chapter11'
import { Icon } from '@/components/Icon'
import { Reveal } from '@/components/Reveal'

export function TrustMetrics() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3" data-stagger>
      {capabilityMetrics.map((m) => (
        <div key={m} className="glass rounded-xl p-4 text-center">
          <div className="w-8 h-8 mx-auto mb-2 rounded-lg bg-cyan/10 flex items-center justify-center">
            <Icon name="check" size={16} className="text-cyan" />
          </div>
          <p className="text-[11px] font-mono uppercase tracking-wider text-ink-300">{m}</p>
        </div>
      ))}
    </div>
  )
}

export function EnterpriseStandards() {
  return (
    <div className="flex flex-wrap gap-2" data-stagger>
      {enterpriseStandards.map((s) => (
        <span key={s} className="chip">
          <Icon name="dot" size={8} className="text-cyan" />
          {s}
        </span>
      ))}
    </div>
  )
}

export function ClientPromise() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5" data-stagger>
      {clientPromise.map((p, i) => (
        <div key={p} className="glass rounded-xl p-4 text-center">
          <div className="w-7 h-7 mx-auto mb-2 rounded-full bg-cyan/10 flex items-center justify-center font-mono text-xs text-cyan">
            {String(i + 1).padStart(2, '0')}
          </div>
          <p className="text-sm text-ink-200">{p}</p>
        </div>
      ))}
    </div>
  )
}

export function TrustAndStandards() {
  return (
    <div className="space-y-12 py-16">
      <Reveal>
        <p className="section-eyebrow mb-3">Trust & Standards</p>
        <h3 className="text-2xl sm:text-3xl font-semibold mb-2 text-ink-100">Engineering Discipline</h3>
        <p className="text-ink-300 max-w-2xl mb-8">
          Every system ships against enterprise-grade standards — not marketing claims.
        </p>
      </Reveal>
      <TrustMetrics />
      <Reveal>
        <h4 className="font-mono text-xs uppercase tracking-[0.3em] text-ink-400 mb-4">Enterprise Standards</h4>
      </Reveal>
      <EnterpriseStandards />
      <Reveal>
        <h4 className="font-mono text-xs uppercase tracking-[0.3em] text-ink-400 mb-4">Client Promise</h4>
      </Reveal>
      <ClientPromise />
    </div>
  )
}
