import { useState } from 'react'
import { workflowVerticals } from '../../data/chapter11'
import { Icon } from '../../components/Icon'
import { Reveal } from '../../components/Reveal'
import { cn } from '../../lib/cn'

export function WorkflowVisualizer() {
  const [active, setActive] = useState(workflowVerticals[0].id)
  const vertical = workflowVerticals.find((v) => v.id === active)!

  return (
    <Reveal>
      <div className="glass-strong rounded-3xl p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <div>
            <h3 className="font-display text-xl font-medium text-white">
              Interactive Workflow Visualizer
            </h3>
            <p className="mt-1 text-sm text-ink-300">
              Select a vertical to compare legacy bottlenecks against the optimized state machine.
            </p>
          </div>
        </div>

        {/* Vertical selector */}
        <div className="flex flex-wrap gap-2 mb-7">
          {workflowVerticals.map((v) => (
            <button
              key={v.id}
              onClick={() => setActive(v.id)}
              className={cn(
                'rounded-xl px-4 py-2 text-sm font-medium transition-all duration-300',
                active === v.id
                  ? 'bg-gradient-to-br from-cyan to-cyan-deep text-ink-950 shadow-[0_0_24px_rgba(34,211,238,0.35)]'
                  : 'glass text-ink-200 hover:border-cyan/30 hover:text-cyan'
              )}
            >
              {v.label}
            </button>
          ))}
        </div>

        {/* Split preview */}
        <div className="grid gap-4 md:grid-cols-2">
          {/* Legacy panel */}
          <div className="glass rounded-2xl p-5 relative overflow-hidden">
            <div className="flex items-center gap-2 mb-4">
              <span className="h-2 w-2 rounded-full bg-accent-rose" />
              <span className="font-mono text-xs uppercase tracking-[0.2em] text-ink-300">
                Legacy Bottlenecks
              </span>
            </div>
            <ul className="space-y-3">
              {vertical.legacy.map((item, i) => (
                <li
                  key={item}
                  className="flex items-start gap-2.5 text-sm text-ink-200 animate-fade-up"
                  style={{ animationDelay: `${i * 80}ms` }}
                >
                  <Icon name="x" size={16} className="mt-0.5 shrink-0 text-accent-rose/70" />
                  {item}
                </li>
              ))}
            </ul>
            <div className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-accent-rose/40 to-transparent" />
          </div>

          {/* Optimized panel */}
          <div className="glass rounded-2xl p-5 relative overflow-hidden border-cyan/20">
            <div className="absolute inset-0 bg-gradient-to-br from-cyan/[0.06] to-transparent pointer-events-none" />
            <div className="relative flex items-center gap-2 mb-4">
              <span className="h-2 w-2 rounded-full bg-cyan animate-pulse-soft" />
              <span className="font-mono text-xs uppercase tracking-[0.2em] text-cyan">
                GK WEBER Optimized State Machine
              </span>
            </div>
            <ul className="relative space-y-3">
              {vertical.optimized.map((item, i) => (
                <li
                  key={item}
                  className="flex items-start gap-2.5 text-sm text-ink-100 animate-fade-up"
                  style={{ animationDelay: `${i * 80 + 100}ms` }}
                >
                  <Icon name="check" size={16} className="mt-0.5 shrink-0 text-cyan" />
                  {item}
                </li>
              ))}
            </ul>
            <div className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-cyan/50 to-transparent" />
          </div>
        </div>
      </div>
    </Reveal>
  )
}
