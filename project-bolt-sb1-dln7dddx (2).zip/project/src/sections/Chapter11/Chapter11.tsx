import { SectionHeading } from '@/components/SectionHeading'
import { SectionDivider } from '@/components/SectionDivider'
import { IsometricComparisonSection } from './IsometricComparison'
import { AdvantageCards } from './AdvantageCardItem'
import { PipelineVisualizer } from './PipelineVisualizer'
import { TrustAndStandards } from './TrustAndStandards'
import { Reveal } from '@/components/Reveal'

export function Chapter11() {
  return (
    <section id="chapter-11" className="relative z-10 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Chapter 11 · Why GK WEBER"
          title={<>The Architecture <span className="text-gradient-cyan">Advantage</span></>}
          description="GK WEBER replaces legacy monolithic front-ends and manual data orchestration with decoupled, event-driven, AI-first systems engineered for enterprise scale."
        />

        <SectionDivider className="my-12" label="11.1 — Isometric Comparison" />
        <IsometricComparisonSection />

        <SectionDivider className="my-12" label="11.2 — Capability Matrix" />
        <Reveal>
          <div className="mb-6">
            <p className="section-eyebrow mb-2">Advantage Matrix</p>
            <h3 className="text-2xl sm:text-3xl font-semibold text-ink-100">
              Six Engineering <span className="text-gradient-cyan">Advantages</span>
            </h3>
          </div>
        </Reveal>
        <AdvantageCards />

        <SectionDivider className="my-12" label="11.3 — Pipeline Visualizer" />
        <Reveal>
          <div className="mb-6">
            <p className="section-eyebrow mb-2">3D Matrix Pipeline</p>
            <h3 className="text-2xl sm:text-3xl font-semibold text-ink-100">
              Operational <span className="text-gradient-cyan">Flow Topography</span>
            </h3>
          </div>
        </Reveal>
        <PipelineVisualizer />

        <SectionDivider className="my-12" label="11.4 — Trust & Standards" />
        <TrustAndStandards />
      </div>
    </section>
  )
}
