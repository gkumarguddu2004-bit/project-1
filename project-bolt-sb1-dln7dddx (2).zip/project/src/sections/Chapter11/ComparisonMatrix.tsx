import { useState } from 'react'
import { comparisonRows } from '../../data/chapter11'
import { Icon } from '../../components/Icon'
import { Reveal } from '../../components/Reveal'
import { cn } from '../../lib/cn'

export function ComparisonMatrix() {
  const [hoveredRow, setHoveredRow] = useState<number | null>(null)

  return (
    <Reveal>
      <div className="glass-strong rounded-3xl overflow-hidden">
        {/* Header */}
        <div className="grid grid-cols-[1.2fr_1fr_1fr]">
          <div className="p-5 sm:p-6 border-b border-r border-white/[0.06]">
            <span className="font-mono text-xs uppercase tracking-[0.2em] text-ink-400">
              Architectural Comparison
            </span>
          </div>
          <div className="p-5 sm:p-6 border-b border-white/[0.06] bg-ink-800/30">
            <span className="font-display text-sm font-medium text-ink-300">
              Traditional Agency
            </span>
          </div>
          <div className="p-5 sm:p-6 border-b border-white/[0.06] bg-cyan/[0.06] relative">
            <div className="absolute inset-0 bg-gradient-to-b from-cyan/10 to-transparent pointer-events-none" />
            <span className="relative font-display text-sm font-medium text-cyan">
              GK WEBER Systems Architecture
            </span>
          </div>
        </div>

        {/* Animated divider */}
        <div className="relative h-px">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan/40 to-transparent animate-shimmer bg-[length:200%_100%]" />
        </div>

        {/* Rows */}
        {comparisonRows.map((row, i) => (
          <div
            key={row.label}
            className="grid grid-cols-[1.2fr_1fr_1fr] transition-colors duration-300"
            onMouseEnter={() => setHoveredRow(i)}
            onMouseLeave={() => setHoveredRow(null)}
          >
            <div
              className={cn(
                'p-4 sm:p-5 border-r border-white/[0.06] transition-colors',
                hoveredRow === i && 'bg-white/[0.02]'
              )}
            >
              <p className="text-xs sm:text-sm font-mono text-ink-300">{row.label}</p>
            </div>
            <div
              className={cn(
                'p-4 sm:p-5 border-r border-white/[0.06] flex items-start gap-2 transition-all',
                hoveredRow === i && 'bg-ink-800/20'
              )}
            >
              <Icon name="x" size={16} className="mt-0.5 shrink-0 text-ink-400" />
              <p className="text-xs sm:text-sm text-ink-300 leading-snug">{row.traditional}</p>
            </div>
            <div
              className={cn(
                'p-4 sm:p-5 flex items-start gap-2 transition-all',
                hoveredRow === i
                  ? 'bg-cyan/[0.08]'
                  : 'bg-cyan/[0.03]'
              )}
            >
              <Icon name="check" size={16} className="mt-0.5 shrink-0 text-cyan" />
              <p className="text-xs sm:text-sm text-ink-100 leading-snug">{row.gkweber}</p>
            </div>
          </div>
        ))}
      </div>
    </Reveal>
  )
}
