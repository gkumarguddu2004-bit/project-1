import { useRef } from 'react'
import { motion, useMotionValue, useSpring } from 'framer-motion'
import { advantageCards, type AdvantageCard } from '@/data/chapter11'
import { Icon } from '@/components/Icon'
import { FresnelGlass } from '@/components/FresnelGlass'

/**
 * AdvantageCardItem — Framer Motion 3D tilt card with depth layers.
 *
 * FIX #3 applied: FresnelGlass wrapper has NO overflow-hidden (fixed in the
 * component itself). Depth layers (icon at translateZ(60px), text at
 * translateZ(30px), watermark at translateZ(0)) rely on preserve-3d being
 * unbroken — no clipping ancestor.
 */
function AdvantageCardItem({ card }: { card: AdvantageCard }) {
  const ref = useRef<HTMLDivElement>(null)
  const rx = useMotionValue(0)
  const ry = useMotionValue(0)
  const srx = useSpring(rx, { stiffness: 200, damping: 20 })
  const sry = useSpring(ry, { stiffness: 200, damping: 20 })

  const onMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    const cx = (e.clientX - rect.left) / rect.width - 0.5
    const cy = (e.clientY - rect.top) / rect.height - 0.5
    ry.set(cx * 16)
    rx.set(-cy * 16)
  }
  const onLeave = () => { rx.set(0); ry.set(0) }

  return (
    <motion.div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      style={{ rotateX: srx, rotateY: sry, transformStyle: 'preserve-3d' }}
      className="h-full"
      data-cursor="view"
    >
      <FresnelGlass className="h-full p-6" rounded="rounded-2xl">
        <div className="preserve-3d h-full flex flex-col">
          {/* Icon at translateZ(60px) */}
          <motion.div
            className="mb-4 inline-flex items-center justify-center w-12 h-12 rounded-xl glass border-cyan/20 text-cyan"
            style={{ transform: 'translateZ(60px)' }}
          >
            <Icon name={card.animation} size={24} />
          </motion.div>

          {/* Title + value at translateZ(30px) */}
          <div style={{ transform: 'translateZ(30px)' }} className="flex-1">
            <h4 className="font-display text-lg font-semibold text-ink-100 mb-2">{card.title}</h4>
            <p className="text-sm text-cyan/80 font-mono mb-3">{card.systemSpec}</p>
            <p className="text-sm text-ink-300 leading-relaxed">{card.value}</p>
          </div>

          {/* Watermark at translateZ(0) */}
          <div
            className="absolute right-4 bottom-4 text-ink-800/40 pointer-events-none"
            style={{ transform: 'translateZ(0px)' }}
          >
            <Icon name={card.animation} size={64} strokeWidth={0.5} />
          </div>
        </div>
      </FresnelGlass>
    </motion.div>
  )
}

export function AdvantageCards() {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3" data-stagger>
      {advantageCards.map((card) => (
        <div key={card.id}>
          <AdvantageCardItem card={card} />
        </div>
      ))}
    </div>
  )
}
