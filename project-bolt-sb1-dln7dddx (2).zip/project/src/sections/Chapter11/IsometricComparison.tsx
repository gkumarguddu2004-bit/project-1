import { useRef } from 'react'
import { motion, useMotionValue, useSpring } from 'framer-motion'
import { comparisonRows } from '@/data/chapter11'
import { Icon } from '@/components/Icon'
import { Reveal } from '@/components/Reveal'
import { cn } from '@/lib/cn'

/**
 * IsometricComparison — two floating isometric slabs.
 *
 * FIX #3 applied: no `overflow-hidden` on slab containers that carry
 * `preserve-3d`. The isometric transform is applied to a wrapper that uses
 * border-radius + backdrop-blur for visual containment instead of clipping.
 */
const ISO_TRANSFORM = 'perspective(1200px) rotateX(25deg) rotateY(-15deg) rotateZ(5deg)'

function Slab({
  variant,
  children,
  className,
}: {
  variant: 'legacy' | 'gkweber'
  children: React.ReactNode
  className?: string
}) {
  const ref = useRef<HTMLDivElement>(null)
  const rx = useMotionValue(0)
  const ry = useMotionValue(0)
  const srx = useSpring(rx, { stiffness: 150, damping: 18 })
  const sry = useSpring(ry, { stiffness: 150, damping: 18 })

  const onMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    const cx = (e.clientX - rect.left) / rect.width - 0.5
    const cy = (e.clientY - rect.top) / rect.height - 0.5
    ry.set(cx * 10)
    rx.set(-cy * 10)
  }
  const onLeave = () => { rx.set(0); ry.set(0) }

  const isCrystal = variant === 'gkweber'

  return (
    <motion.div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      className="scene preserve-3d"
      style={{ perspective: 1200 }}
      data-cursor="view"
    >
      <motion.div
        className={cn(
          'relative preserve-3d rounded-2xl p-6 transition-shadow duration-500',
          isCrystal ? 'crystal-glass' : 'cracked',
          className
        )}
        style={{
          transform: ISO_TRANSFORM,
          rotateX: srx,
          rotateY: sry,
        }}
        whileHover={isCrystal ? { y: -12 } : { y: 8, rotateZ: 3 }}
        transition={{ type: 'spring', stiffness: 200, damping: 20 }}
      >
        {/* AO shadow underneath */}
        <div className={cn('absolute inset-x-4 -bottom-6 h-12 rounded-full', isCrystal ? 'ao-shadow-cyan' : 'ao-shadow')} />
        {children}
      </motion.div>
    </motion.div>
  )
}

export function IsometricComparison() {
  return (
    <div className="grid gap-12 lg:grid-cols-2 items-center">
      <Slab variant="legacy">
        <div className="flex items-center gap-2 mb-5">
          <Icon name="crack" size={20} className="text-accent-rose" />
          <h3 className="font-display text-lg font-semibold text-ink-200">Legacy Architecture</h3>
        </div>
        <ul className="space-y-3">
          {comparisonRows.map((row) => (
            <li key={row.label} className="flex items-start gap-3">
              <Icon name="close" size={16} className="text-accent-rose/70 mt-0.5 shrink-0" />
              <div>
                <p className="text-xs font-mono uppercase tracking-wider text-ink-400">{row.label}</p>
                <p className="text-sm text-ink-300">{row.traditional}</p>
              </div>
            </li>
          ))}
        </ul>
      </Slab>

      <Slab variant="gkweber">
        <div className="flex items-center gap-2 mb-5">
          <Icon name="spark" size={20} className="text-cyan" />
          <h3 className="font-display text-lg font-semibold text-ink-100">GK WEBER Architecture</h3>
        </div>
        <ul className="space-y-3">
          {comparisonRows.map((row) => (
            <li key={row.label} className="flex items-start gap-3">
              <Icon name="check" size={16} className="text-cyan mt-0.5 shrink-0" />
              <div>
                <p className="text-xs font-mono uppercase tracking-wider text-cyan/70">{row.label}</p>
                <p className="text-sm text-ink-100">{row.gkweber}</p>
              </div>
            </li>
          ))}
        </ul>
      </Slab>
    </div>
  )
}

export function IsometricComparisonSection() {
  return (
    <div className="py-16">
      <Reveal>
        <p className="section-eyebrow mb-3">Isometric Architecture Comparison</p>
        <h3 className="text-2xl sm:text-3xl font-semibold mb-2 text-ink-100">
          Legacy Monolith vs. <span className="text-gradient-cyan">GK WEBER Spatial Stack</span>
        </h3>
        <p className="text-ink-300 max-w-2xl mb-10">
          Two operational paradigms placed side-by-side in 3D space. Hover each slab to inspect its structural integrity.
        </p>
      </Reveal>
      <IsometricComparison />
    </div>
  )
}
