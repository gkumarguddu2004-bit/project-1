import { testimonials, clientLogos, complianceBadges, outcomeCards } from '@/data/chapter13'
import { Icon, type IconName } from '@/components/Icon'
import { Reveal } from '@/components/Reveal'

export function OutcomeCards() {
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3" data-stagger>
      {outcomeCards.map((card) => (
        <div key={card.id} className="glass-card glass-card-hover p-5" data-cursor="view">
          <div className="w-10 h-10 rounded-xl bg-cyan/10 flex items-center justify-center mb-3">
            <Icon name={card.icon as IconName} size={20} className="text-cyan" />
          </div>
          <h4 className="font-display text-base font-semibold text-ink-100 mb-2">{card.title}</h4>
          <p className="text-sm text-ink-300 leading-relaxed">{card.description}</p>
        </div>
      ))}
    </div>
  )
}

export function TestimonialWall() {
  return (
    <div className="grid gap-6 lg:grid-cols-3" data-stagger>
      {testimonials.map((t) => (
        <div key={t.id} className="glass-strong rounded-2xl p-6 relative">
          <Icon name="quote" size={32} className="text-cyan/20 absolute top-4 right-4" />
          <p className="text-sm text-ink-200 italic leading-relaxed mb-5">{t.quote}</p>
          <div className="pt-4 border-t border-white/[0.05]">
            <p className="font-display text-sm font-semibold text-ink-100">{t.name}</p>
            <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-cyan/60 mt-1">
              {t.role} · {t.company}
            </p>
          </div>
        </div>
      ))}
    </div>
  )
}

export function ClientLogos() {
  return (
    <div className="flex flex-wrap items-center justify-center gap-4">
      {clientLogos.map((logo) => (
        <div
          key={logo}
          className="glass rounded-xl px-5 py-3 text-sm font-mono text-ink-300 hover:text-cyan transition-colors"
          data-cursor="link"
        >
          {logo}
        </div>
      ))}
    </div>
  )
}

export function ComplianceBadges() {
  return (
    <div className="flex flex-wrap justify-center gap-3" data-stagger>
      {complianceBadges.map((badge) => (
        <div key={badge} className="inline-flex items-center gap-2 glass rounded-lg px-4 py-2">
          <Icon name="shield" size={14} className="text-cyan/70" />
          <span className="text-xs font-mono text-ink-300">{badge}</span>
        </div>
      ))}
    </div>
  )
}

export function SocialProof() {
  return (
    <div className="space-y-12 py-8">
      <Reveal>
        <div className="text-center mb-8">
          <p className="section-eyebrow mb-3">Client Outcomes</p>
          <h3 className="text-2xl sm:text-3xl font-semibold text-ink-100">
            Measurable <span className="text-gradient-cyan">Business Results</span>
          </h3>
        </div>
      </Reveal>
      <OutcomeCards />
      <Reveal>
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-ink-400 text-center mb-6">Trusted By</p>
      </Reveal>
      <ClientLogos />
      <Reveal>
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-ink-400 text-center mb-6">Voices from the Field</p>
      </Reveal>
      <TestimonialWall />
      <Reveal>
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-ink-400 text-center mb-6">Compliance & Standards</p>
      </Reveal>
      <ComplianceBadges />
    </div>
  )
}
