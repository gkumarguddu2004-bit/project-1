import { SectionHeading } from '@/components/SectionHeading'
import { SectionDivider } from '@/components/SectionDivider'
import { KpiDashboard } from './KpiDashboard'
import { RoiCalculator } from './RoiCalculator'
import { SocialProof } from './SocialProof'
import { Reveal } from '@/components/Reveal'

export function Chapter13() {
  return (
    <section id="chapter-13" className="relative z-10 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Chapter 13 · Business Results"
          title={<>Outcomes, Not <span className="text-gradient-cyan">Vanity Metrics</span></>}
          description="Capability statements and measurable operational impact — engineered for enterprise procurement standards, not marketing dashboards."
        />

        <SectionDivider className="my-12" label="13.1 — System Telemetry" />
        <Reveal>
          <div className="mb-6">
            <p className="section-eyebrow mb-2">Live KPI Dashboard</p>
            <h3 className="text-2xl sm:text-3xl font-semibold text-ink-100">
              Operational <span className="text-gradient-cyan">Telemetry</span>
            </h3>
          </div>
        </Reveal>
        <KpiDashboard />

        <SectionDivider className="my-12" label="13.2 — ROI Calculator" />
        <RoiCalculator />

        <SectionDivider className="my-12" label="13.3 — Social Proof" />
        <SocialProof />
      </div>
    </section>
  )
}
