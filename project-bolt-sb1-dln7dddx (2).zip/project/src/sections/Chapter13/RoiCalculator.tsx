import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { roiConfig } from '@/data/chapter13'
import { Icon } from '@/components/Icon'
import { Reveal } from '@/components/Reveal'

/**
 * RoiCalculator — preserves the formula:
 *   hoursSaved = (volume * time) / 60
 * Displays the acceleration multiplier from roiConfig.
 */
export function RoiCalculator() {
  const [volume, setVolume] = useState(roiConfig.volume.default)
  const [time, setTime] = useState(roiConfig.time.default)

  const hoursSaved = useMemo(() => (volume * time) / 60, [volume, time])
  const formatted = useMemo(() => {
    if (hoursSaved >= 10000) return `${(hoursSaved / 1000).toFixed(1)}k`
    if (hoursSaved >= 1000) return hoursSaved.toFixed(0)
    return hoursSaved.toFixed(1)
  }, [hoursSaved])

  return (
    <Reveal>
      <div className="glass-strong rounded-2xl p-6 sm:p-8">
        <div className="flex items-center gap-2 mb-6">
          <Icon name="chart" size={20} className="text-cyan" />
          <h3 className="text-xl font-semibold text-ink-100">ROI Acceleration Calculator</h3>
        </div>

        <div className="grid gap-8 lg:grid-cols-[1fr_auto] items-center">
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="font-mono text-xs uppercase tracking-wider text-ink-300">
                  {roiConfig.volume.label}
                </label>
                <span className="font-mono text-sm text-cyan">{volume.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min={roiConfig.volume.min}
                max={roiConfig.volume.max}
                step={500}
                value={volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                className="w-full accent-cyan"
                data-cursor="drag"
              />
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="font-mono text-xs uppercase tracking-wider text-ink-300">
                  {roiConfig.time.label}
                </label>
                <span className="font-mono text-sm text-cyan">{time} min</span>
              </div>
              <input
                type="range"
                min={roiConfig.time.min}
                max={roiConfig.time.max}
                step={1}
                value={time}
                onChange={(e) => setTime(Number(e.target.value))}
                className="w-full accent-cyan"
                data-cursor="drag"
              />
            </div>
          </div>

          <div className="text-center lg:text-right">
            <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-ink-400 mb-1">Monthly Hours Reclaimed</p>
            <motion.p
              key={formatted}
              initial={{ opacity: 0.5, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              className="font-display text-4xl sm:text-5xl font-semibold text-gradient-cyan"
            >
              {formatted}
            </motion.p>
            <p className="font-mono text-sm text-cyan/70 mt-2">{roiConfig.acceleration} acceleration</p>
          </div>
        </div>

        <p className="mt-6 pt-6 border-t border-white/[0.05] text-xs text-ink-400 font-mono">
          Formula: hoursSaved = (volume × time) / 60 — projection only, not a guarantee.
        </p>
      </div>
    </Reveal>
  )
}
