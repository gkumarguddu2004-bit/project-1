import { kpiCards } from '@/data/chapter13'
import { Icon, type IconName } from '@/components/Icon'
import { cn } from '@/lib/cn'

export function KpiDashboard() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" data-stagger>
      {kpiCards.map((kpi) => (
        <div
          key={kpi.id}
          className={cn(
            'glass-card glass-card-hover p-5 relative preserve-3d',
            kpi.trend === 'active' && 'glow-ring'
          )}
          data-cursor="view"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-cyan/10 flex items-center justify-center">
              <Icon name={kpi.icon as IconName} size={20} className="text-cyan" />
            </div>
            <span
              className={cn(
                'w-2 h-2 rounded-full',
                kpi.trend === 'up' && 'bg-accent-emerald animate-pulse-soft',
                kpi.trend === 'active' && 'bg-cyan animate-pulse-soft',
                kpi.trend === 'stable' && 'bg-ink-400'
              )}
            />
          </div>
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-400 mb-1">{kpi.title}</p>
          <p className="font-display text-2xl font-semibold text-ink-100 mb-2">{kpi.metric}</p>
          <p className="text-xs text-ink-300 leading-relaxed">{kpi.explanation}</p>
        </div>
      ))}
    </div>
  )
}
