import { useEffect, useRef } from 'react'

/**
 * WaveformCanvas — Canvas2D audio waveform.
 *  - idle: gentle cyan ripples
 *  - active: particle vortex
 *
 * FIX #2 applied: strict null check on getContext('2d'); RAF loop breaks
 * immediately if canvas or context becomes null. Uses ResizeObserver for sizing.
 */
export function WaveformCanvas({
  active,
  className,
}: {
  active: boolean
  className?: string
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const activeRef = useRef(active)
  activeRef.current = active

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return // FIX #2: strict null check

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    let dpr = Math.min(window.devicePixelRatio || 1, 2)
    let w = 0
    let h = 0

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      w = canvas.clientWidth
      h = canvas.clientHeight
      if (w === 0 || h === 0) return
      canvas.width = w * dpr
      canvas.height = h * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()

    const ro = new ResizeObserver(resize)
    ro.observe(canvas)

    let t = 0
    let rafId = 0

    const render = () => {
      // FIX #2: break RAF immediately if canvas/context lost
      if (!canvas || !ctx) return
      if (w === 0 || h === 0) { rafId = requestAnimationFrame(render); return }

      t += 0.02
      const isActive = activeRef.current

      ctx.clearRect(0, 0, w, h)
      const cx = w / 2
      const cy = h / 2

      if (isActive && !reduceMotion) {
        // Particle vortex
        const arms = 5
        for (let a = 0; a < arms; a++) {
          ctx.beginPath()
          for (let i = 0; i < 60; i++) {
            const angle = (a / arms) * Math.PI * 2 + t + (i / 60) * Math.PI * 2
            const radius = i * 2.2
            const x = cx + Math.cos(angle) * radius
            const y = cy + Math.sin(angle) * radius
            if (i === 0) ctx.moveTo(x, y)
            else ctx.lineTo(x, y)
          }
          ctx.strokeStyle = `rgba(34,211,238,${0.4 - a * 0.05})`
          ctx.lineWidth = 1.5
          ctx.stroke()
        }
        // Core pulse
        const pulseR = 8 + Math.sin(t * 4) * 4
        ctx.beginPath()
        ctx.arc(cx, cy, pulseR, 0, Math.PI * 2)
        ctx.fillStyle = 'rgba(34,211,238,0.6)'
        ctx.fill()
        ctx.beginPath()
        ctx.arc(cx, cy, pulseR * 2, 0, Math.PI * 2)
        ctx.fillStyle = 'rgba(103,232,249,0.15)'
        ctx.fill()
      } else {
        // Idle gentle ripples
        for (let i = 0; i < 4; i++) {
          const r = ((t * 30 + i * 25) % 80) + 10
          const alpha = Math.max(0, 1 - r / 80) * 0.3
          ctx.beginPath()
          ctx.arc(cx, cy, r, 0, Math.PI * 2)
          ctx.strokeStyle = `rgba(34,211,238,${alpha})`
          ctx.lineWidth = 1.2
          ctx.stroke()
        }
        // Static center
        ctx.beginPath()
        ctx.arc(cx, cy, 4, 0, Math.PI * 2)
        ctx.fillStyle = 'rgba(34,211,238,0.5)'
        ctx.fill()
      }

      rafId = requestAnimationFrame(render)
    }
    rafId = requestAnimationFrame(render)

    return () => {
      cancelAnimationFrame(rafId)
      ro.disconnect()
    }
  }, [])

  return <canvas ref={canvasRef} className={className} aria-hidden="true" />
}
