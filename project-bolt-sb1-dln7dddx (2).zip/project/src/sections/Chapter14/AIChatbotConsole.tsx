import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Icon } from '@/components/Icon'
import { OrbCore } from './OrbCore'
import { createScramble } from '@/lib/scramble'
import { cn } from '@/lib/cn'

interface Message { id: number; role: 'agent' | 'user'; text: string }

const FLOW: { agent: string; choices: string[] }[] = [
  {
    agent: 'System initialized. I am the GK WEBER diagnostic agent. What operational bottleneck are you experiencing?',
    choices: ['Manual data processing', 'System performance lag', 'Scaling limitations'],
  },
  {
    agent: 'Acknowledged. What is your current monthly transaction or data volume?',
    choices: ['Under 10k units', '10k–100k units', 'Over 100k units'],
  },
  {
    agent: 'Diagnostic complete. Based on your profile, a decoupled event-driven architecture with parallel AI microservices would reclaim significant operational capacity. Would you like the full systems audit?',
    choices: ['Request full audit', 'View portfolio examples'],
  },
]

export function AIChatbotConsole() {
  const [messages, setMessages] = useState<Message[]>([{ id: 0, role: 'agent', text: '' }])
  const [step, setStep] = useState(0)
  const [scramble, setScramble] = useState('')
  const [typing, setTyping] = useState(true)
  const logRef = useRef<HTMLDivElement>(null)
  const msgId = useRef(1)

  useEffect(() => {
    if (step >= FLOW.length) return
    setTyping(true)
    setScramble('')
    const stop = createScramble(FLOW[step].agent, setScramble, () => setTyping(false), 800, 24)
    return stop
  }, [step])

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight
  }, [messages, scramble])

  const choose = (choice: string) => {
    setMessages((m) => [...m, { id: msgId.current++, role: 'user', text: choice }])
    setTimeout(() => {
      setMessages((m) => [...m, { id: msgId.current++, role: 'agent', text: '' }])
      setStep((s) => Math.min(s + 1, FLOW.length - 1))
    }, 400)
  }

  const lastAgent = [...messages].reverse().find((m) => m.role === 'agent')

  return (
    <div className="glass-strong rounded-2xl p-6 preserve-3d" data-flyin>
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-accent-emerald animate-pulse-soft" />
          <h3 className="font-display text-lg font-semibold text-ink-100">AI Diagnostic Console</h3>
        </div>
        <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-400">Agent v10.0</span>
      </div>

      <div className="flex flex-col sm:flex-row gap-6">
        {/* Orb core */}
        <div className="flex items-center justify-center shrink-0">
          <OrbCore active={typing} />
        </div>

        {/* Chat log */}
        <div className="flex-1 min-w-0">
          <div ref={logRef} className="h-48 overflow-y-auto space-y-3 pr-2 mb-4">
            {messages.filter((m) => m.role === 'user').map((m) => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex justify-end"
              >
                <div className="max-w-[80%] rounded-xl rounded-br-sm bg-cyan/15 border border-cyan/20 px-3.5 py-2 text-sm text-ink-100">
                  {m.text}
                </div>
              </motion.div>
            ))}
            {/* Latest agent message (scrambling) */}
            {lastAgent && (
              <motion.div
                key={lastAgent.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex justify-start gap-2"
              >
                <Icon name="brain" size={18} className="text-cyan mt-1 shrink-0" />
                <div className="max-w-[85%] rounded-xl rounded-bl-sm glass px-3.5 py-2 text-sm text-ink-200">
                  {scramble || FLOW[step].agent}
                  {typing && <span className="inline-block w-1.5 h-3.5 bg-cyan ml-0.5 animate-pulse-soft align-middle" />}
                </div>
              </motion.div>
            )}
          </div>

          {/* Choice chips */}
          <AnimatePresence mode="wait">
            {!typing && step < FLOW.length && (
              <motion.div
                key={step}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-wrap gap-2"
              >
                {FLOW[step].choices.map((c) => (
                  <button
                    key={c}
                    onClick={() => choose(c)}
                    data-cursor="cta"
                    className={cn(
                      'chip hover:scale-105 transition-transform',
                      'hover:border-cyan/40 hover:text-cyan'
                    )}
                  >
                    <Icon name="arrow-right" size={12} />
                    {c}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}
