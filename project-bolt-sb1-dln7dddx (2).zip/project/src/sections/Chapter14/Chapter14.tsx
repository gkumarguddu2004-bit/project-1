import { SectionHeading } from '@/components/SectionHeading'
import { SectionDivider } from '@/components/SectionDivider'
import { AIChatbotConsole } from './AIChatbotConsole'
import { VoiceAgentRadar } from './VoiceAgentRadar'
import { Reveal } from '@/components/Reveal'
import { Icon } from '@/components/Icon'

const AGENT_FEATURES = [
  { icon: 'neural' as const, title: 'Isolated LLM Runtime', desc: 'Zero blocking loops — async queue handling for unstructured inputs.' },
  { icon: 'activity' as const, title: 'Live Telemetry', desc: 'Real-time confidence, latency, and throughput monitoring.' },
  { icon: 'shield' as const, title: 'Zero-Trust Boundary', desc: 'Every agent request runs against authenticated, isolated runtimes.' },
]

export function Chapter14() {
  return (
    <section id="chapter-14" className="relative z-10 py-24 sm:py-32 scene preserve-3d">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 preserve-3d">
        <SectionHeading
          eyebrow="Chapter 14 · AI Agent Suite"
          title={<>Engage the <span className="text-gradient-cyan">Agent Console</span></>}
          description="A diagnostic AI agent and voice radar — purpose-built to qualify operational bottlenecks and route them to the right architecture pattern."
        />

        <SectionDivider className="my-12" label="14.1 — Agent Capabilities" />
        <div className="grid gap-5 sm:grid-cols-3 mb-12" data-stagger>
          {AGENT_FEATURES.map((f) => (
            <div key={f.title} className="glass-card glass-card-hover p-5">
              <div className="w-10 h-10 rounded-xl bg-cyan/10 flex items-center justify-center mb-3">
                <Icon name={f.icon} size={20} className="text-cyan" />
              </div>
              <h4 className="font-display text-base font-semibold text-ink-100 mb-2">{f.title}</h4>
              <p className="text-sm text-ink-300 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>

        <SectionDivider className="my-12" label="14.2 — Live Console" />
        <Reveal>
          <p className="section-eyebrow mb-4 text-center">Interactive Agents</p>
        </Reveal>
        <div className="grid gap-6 lg:grid-cols-2">
          <AIChatbotConsole />
          <VoiceAgentRadar />
        </div>
      </div>
    </section>
  )
}
