import { motion } from 'framer-motion'
import { Icon } from '@/components/Icon'

/**
 * OrbCore — 3D CSS pulsing AI brain with rotating rings and radial glow.
 * Uses preserve-3d for ring depth — NO overflow-hidden on any ancestor.
 */
export function OrbCore({ active = false }: { active?: boolean }) {
  return (
    <div className="relative scene preserve-3d flex items-center justify-center" style={{ width: 200, height: 200 }}>
      {/* Radial glow */}
      <motion.div
        className="absolute inset-0 rounded-full"
        style={{ background: 'radial-gradient(circle, rgba(34,211,238,0.3), transparent 65%)' }}
        animate={{ scale: active ? [1, 1.15, 1] : [1, 1.08, 1], opacity: [0.6, 0.9, 0.6] }}
        transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
      />

      {/* Outer ring */}
      <motion.div
        className="absolute inset-0 rounded-full border border-cyan/30 preserve-3d"
        style={{ transform: 'rotateX(70deg)' }}
        animate={{ rotateZ: 360 }}
        transition={{ duration: 12, repeat: Infinity, ease: 'linear' }}
      >
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-cyan shadow-[0_0_10px_rgba(34,211,238,0.8)]" />
      </motion.div>

      {/* Middle ring */}
      <motion.div
        className="absolute inset-4 rounded-full border border-cyan/20 preserve-3d"
        style={{ transform: 'rotateX(70deg) rotateY(60deg)' }}
        animate={{ rotateZ: -360 }}
        transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
      >
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-cyan-glow shadow-[0_0_8px_rgba(103,232,249,0.8)]" />
      </motion.div>

      {/* Inner ring */}
      <motion.div
        className="absolute inset-8 rounded-full border border-cyan/15"
        style={{ transform: 'rotateY(30deg)' }}
        animate={{ rotateZ: 360 }}
        transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
      />

      {/* Core */}
      <motion.div
        className="relative z-10 w-16 h-16 rounded-full bg-gradient-to-br from-cyan/30 to-cyan-deep/40 backdrop-blur-md flex items-center justify-center"
        style={{ boxShadow: '0 0 40px rgba(34,211,238,0.4), inset 0 0 20px rgba(34,211,238,0.2)' }}
        animate={{ scale: active ? [1, 1.1, 1] : [1, 1.05, 1] }}
        transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
      >
        <Icon name="brain" size={28} className="text-cyan-glow" />
      </motion.div>
    </div>
  )
}
