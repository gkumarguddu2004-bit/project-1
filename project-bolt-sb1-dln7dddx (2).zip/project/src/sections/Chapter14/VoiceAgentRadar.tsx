import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Icon } from '@/components/Icon'
import { WaveformCanvas } from './WaveformCanvas'
import { cn } from '@/lib/cn'

const TELEMETRY = [
  { label: 'Latency', value: '42ms' },
  { label: 'Confidence', value: '97.4%' },
  { label: 'Active Nodes', value: '128' },
  { label: 'Throughput', value: '8.2k/s' },
]

function SlotTicker({ value }: { value: string }) {
  const [display, setDisplay] = useState(value)
  const intervalRef = useRef<ReturnType<typeof setInterval>>()

  useEffect(() => {
    const chars = '0123456789.%kms/'
    intervalRef.current = setInterval(() => {
      let out = ''
      for (let i = 0; i < value.length; i++) {
        const ch = value[i]
        if (ch.match(/[0-9.%kms/]/)) {
          out += Math.random() > 0.7 ? ch : chars[Math.floor(Math.random() * chars.length)]
        } else {
          out += ch
        }
      }
      setDisplay(out)
    }, 60)
    return () => clearInterval(intervalRef.current)
  }, [value])

  return <span className="font-mono text-cyan tabular-nums">{display}</span>
}

export function VoiceAgentRadar() {
  const [active, setActive] = useState(false)

  return (
    <div className="glass-strong rounded-2xl p-6 preserve-3d" data-flyin>
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <Icon name="mic" size={18} className="text-cyan" />
          <h3 className="font-display text-lg font-semibold text-ink-100">Voice Agent Radar</h3>
        </div>
        <span
          className={cn(
            'font-mono text-[10px] uppercase tracking-[0.2em]',
            active ? 'text-accent-emerald' : 'text-ink-400'
          )}
        >
          {active ? '● Listening' : '○ Standby'}
        </span>
      </div>

      <div className="grid sm:grid-cols-[1fr_auto] gap-6 items-center">
        {/* Waveform */}
        <div className="relative h-32 rounded-xl glass overflow-hidden">
          <WaveformCanvas active={active} className="w-full h-full" />
        </div>

        {/* Activate button */}
        <button
          onClick={() => setActive((v) => !v)}
          data-cursor="cta"
          className={cn(
            'relative px-6 py-4 rounded-xl font-mono text-sm uppercase tracking-wider transition-all duration-300',
            active
              ? 'bg-accent-rose/15 border border-accent-rose/30 text-accent-rose'
              : 'bg-gradient-to-br from-cyan to-cyan-deep text-ink-950 hover:shadow-[0_0_30px_rgba(34,211,238,0.4)]'
          )}
        >
          <Icon name={active ? 'close' : 'mic'} size={18} className="mr-2 inline" />
          {active ? 'Deactivate' : 'Activate Voice Node'}
        </button>
      </div>

      {/* Telemetry HUD */}
      <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3">
        {TELEMETRY.map((t) => (
          <div key={t.label} className="glass rounded-lg p-3">
            <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-ink-400 mb-1">{t.label}</p>
            <AnimatePresence mode="wait">
              <motion.div
                key={active ? 'on' : 'off'}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                {active ? <SlotTicker value={t.value} /> : <span className="font-mono text-ink-500">— — —</span>}
              </motion.div>
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  )
}
