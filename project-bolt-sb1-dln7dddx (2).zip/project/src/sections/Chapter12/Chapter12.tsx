import { SectionHeading } from '@/components/SectionHeading'
import { SectionDivider } from '@/components/SectionDivider'
import { FeaturedCaseStudy } from './FeaturedCaseStudy'
import { PortfolioGrid } from './PortfolioGrid'
import { Reveal } from '@/components/Reveal'

export function Chapter12() {
  return (
    <section id="chapter-12" className="relative z-10 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Chapter 12 · Portfolio"
          title={<>Selected <span className="text-gradient-cyan">Engineering Work</span></>}
          description="Systems architecture and AI automation deployments across FinTech, Logistics, SaaS, and Commerce — each engineered against enterprise procurement standards."
        />

        <SectionDivider className="my-12" label="12.1 — Flagship Case Study" />
        <FeaturedCaseStudy />

        <SectionDivider className="my-12" label="12.2 — Full Portfolio" />
        <Reveal>
          <div className="mb-6">
            <p className="section-eyebrow mb-2">Project Archive</p>
            <h3 className="text-2xl sm:text-3xl font-semibold text-ink-100">
              Complete <span className="text-gradient-cyan">Deployment Catalog</span>
            </h3>
          </div>
        </Reveal>
        <PortfolioGrid />
      </div>
    </section>
  )
}
