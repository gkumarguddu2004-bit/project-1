import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { projects, projectCategories, type Project } from '@/data/chapter12'
import { Icon } from '@/components/Icon'
import { ProjectDetailPanel } from './ProjectDetailPanel'
import { cn } from '@/lib/cn'

export function PortfolioGrid() {
  const [filter, setFilter] = useState<string>('All')
  const [selected, setSelected] = useState<Project | null>(null)

  const filtered = filter === 'All' ? projects : projects.filter((p) => p.category === filter)

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-8">
        {projectCategories.map((cat) => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            data-cursor="link"
            className={cn(
              'px-4 py-2 rounded-lg text-xs font-mono uppercase tracking-wider transition-all',
              filter === cat
                ? 'bg-cyan/15 text-cyan border border-cyan/30'
                : 'glass text-ink-300 hover:text-ink-100'
            )}
          >
            {cat}
          </button>
        ))}
      </div>

      <motion.div layout className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3" data-stagger>
        <AnimatePresence mode="popLayout">
          {filtered.map((project) => (
            <motion.button
              key={project.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              onClick={() => setSelected(project)}
              data-cursor="view"
              className="group glass-card glass-card-hover text-left p-0"
            >
              <div className="relative aspect-[4/3] rounded-t-2xl overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/80 via-transparent to-transparent" />
                <span className="absolute top-3 left-3 chip">{project.category}</span>
              </div>
              <div className="p-5">
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-cyan/60 mb-2">{project.industry}</p>
                <h4 className="font-display text-base font-semibold text-ink-100 mb-2 group-hover:text-cyan transition-colors">
                  {project.title}
                </h4>
                <p className="text-sm text-ink-300 line-clamp-2 mb-3">{project.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-cyan/70">{project.outcome}</span>
                  <Icon name="arrow-up-right" size={16} className="text-ink-400 group-hover:text-cyan transition-colors" />
                </div>
              </div>
            </motion.button>
          ))}
        </AnimatePresence>
      </motion.div>

      <ProjectDetailPanel project={selected} onClose={() => setSelected(null)} />
    </div>
  )
}
