import { useRef } from 'react'
import { motion, useMotionValue, useSpring } from 'framer-motion'
import { flagshipTechTags, flagshipTestimonial, caseStudyTimeline } from '@/data/chapter12'
import { Icon } from '@/components/Icon'
import { Reveal } from '@/components/Reveal'

/**
 * FeaturedCaseStudy — flagship case study with 3D image container.
 *
 * FIX #3 applied: the 3D image container uses border-radius for visual
 * containment — NO `overflow-hidden` on the preserve-3d parent. The image
 * is clipped via `rounded-2xl` on the <img> itself, not the wrapper.
 */
export function FeaturedCaseStudy() {
  const ref = useRef<HTMLDivElement>(null)
  const rx = useMotionValue(0)
  const ry = useMotionValue(0)
  const srx = useSpring(rx, { stiffness: 150, damping: 18 })
  const sry = useSpring(ry, { stiffness: 150, damping: 18 })

  const onMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    const cx = (e.clientX - rect.left) / rect.width - 0.5
    const cy = (e.clientY - rect.top) / rect.height - 0.5
    ry.set(cx * 12)
    rx.set(-cy * 12)
  }
  const onLeave = () => { rx.set(0); ry.set(0) }

  return (
    <div className="grid gap-10 lg:grid-cols-2 items-center py-12">
      {/* 3D image container — NO overflow-hidden on preserve-3d parent */}
      <motion.div
        ref={ref}
        onMouseMove={onMove}
        onMouseLeave={onLeave}
        className="scene preserve-3d"
        data-cursor="view"
      >
        <motion.div
          className="relative preserve-3d rounded-2xl"
          style={{ rotateX: srx, rotateY: sry, transformStyle: 'preserve-3d' }}
        >
          <img
            src="https://images.pexels.com/photos/4457420/pexels-photo-4457420.jpeg?auto=compress&cs=tinysrgb&w=1000"
            alt="Logistics automation architecture"
            className="rounded-2xl crystal-glass w-full aspect-[4/3] object-cover"
            style={{ transform: 'translateZ(20px)' }}
            loading="lazy"
          />
          <div
            className="absolute -bottom-4 -right-4 glass-strong rounded-xl p-4 max-w-[200px]"
            style={{ transform: 'translateZ(60px)' }}
          >
            <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-cyan/70 mb-1">Processing Time</p>
            <p className="font-display text-2xl font-semibold text-ink-100">42 min → 1.8s</p>
          </div>
        </motion.div>
      </motion.div>

      {/* Content */}
      <div>
        <Reveal>
          <p className="section-eyebrow mb-3">Flagship Case Study</p>
          <h3 className="text-2xl sm:text-3xl font-semibold text-ink-100 mb-4">
            High-Volume Logistics <span className="text-gradient-cyan">Automation Architecture</span>
          </h3>
          <p className="text-ink-300 leading-relaxed mb-6">
            Asynchronous data extraction architecture replacing manual shipping document verification with parallel AI processing microservices.
          </p>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="flex flex-wrap gap-2 mb-6">
            {flagshipTechTags.map((tag) => (
              <span key={tag} className="chip">{tag}</span>
            ))}
          </div>
        </Reveal>

        <Reveal delay={0.15}>
          <div className="relative glass-strong rounded-xl p-5 mb-6">
            <Icon name="quote" size={28} className="text-cyan/30 absolute top-3 right-3" />
            <p className="text-sm text-ink-200 italic leading-relaxed mb-3">{flagshipTestimonial.text}</p>
            <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-400">
              {flagshipTestimonial.role} · {flagshipTestimonial.company}
            </p>
          </div>
        </Reveal>

        <Reveal delay={0.2}>
          <div className="relative pl-4">
            <div className="absolute left-0 top-0 bottom-0 w-px bg-gradient-to-b from-cyan/40 via-cyan/20 to-transparent" />
            {caseStudyTimeline.map((phase) => (
              <div key={phase.phase} className="relative mb-4 last:mb-0">
                <div className="absolute -left-4 top-1.5 w-2 h-2 rounded-full bg-cyan shadow-[0_0_8px_rgba(34,211,238,0.6)]" />
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-cyan/70">{phase.phase}</p>
                <p className="text-sm text-ink-300">{phase.detail}</p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </div>
  )
}
