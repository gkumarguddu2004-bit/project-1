import { motion, AnimatePresence } from 'framer-motion'
import { type Project } from '@/data/chapter12'
import { Icon } from '@/components/Icon'

export function ProjectDetailPanel({
  project,
  onClose,
}: {
  project: Project | null
  onClose: () => void
}) {
  return (
    <AnimatePresence>
      {project && (
        <motion.div
          className="fixed inset-0 z-[80] flex items-center justify-center p-4 sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <div className="absolute inset-0 bg-ink-950/80 backdrop-blur-md" />
          <motion.div
            className="relative glass-strong rounded-2xl max-w-3xl w-full max-h-[85vh] overflow-y-auto"
            initial={{ scale: 0.92, y: 30, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.92, y: 30, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 260, damping: 24 }}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={onClose}
              data-cursor="link"
              className="absolute top-4 right-4 z-10 p-2 rounded-lg glass text-ink-300 hover:text-cyan transition-colors"
              aria-label="Close panel"
            >
              <Icon name="close" size={20} />
            </button>

            <div className="relative aspect-[16/7] rounded-t-2xl overflow-hidden">
              <img src={project.image} alt={project.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-900 via-ink-900/40 to-transparent" />
              <div className="absolute bottom-4 left-6 right-6">
                <span className="chip mb-2">{project.category}</span>
                <h3 className="text-xl sm:text-2xl font-display font-semibold text-ink-100">{project.title}</h3>
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-cyan/70 mt-1">{project.industry}</p>
              </div>
            </div>

            <div className="p-6 space-y-5">
              <p className="text-ink-200 leading-relaxed">{project.description}</p>

              <div className="grid sm:grid-cols-3 gap-4">
                <div className="glass rounded-xl p-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-accent-rose/70 mb-2">Challenge</p>
                  <p className="text-sm text-ink-300">{project.challenge}</p>
                </div>
                <div className="glass rounded-xl p-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-cyan/70 mb-2">Strategy</p>
                  <p className="text-sm text-ink-300">{project.strategy}</p>
                </div>
                <div className="glass rounded-xl p-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-accent-emerald/70 mb-2">Impact</p>
                  <p className="text-sm text-ink-300">{project.impact}</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {project.techTags.map((tag) => (
                  <span key={tag} className="chip">{tag}</span>
                ))}
              </div>

              <div className="flex items-center gap-3 pt-2 border-t border-white/[0.05]">
                <Icon name="bolt" size={18} className="text-cyan" />
                <span className="font-mono text-sm text-cyan">{project.outcome}</span>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
