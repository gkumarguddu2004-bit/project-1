import { useEffect, useState } from 'react'
import { QuantumCanvas } from '@/components/QuantumCanvas'
import { BackgroundAtmosphere } from '@/components/BackgroundAtmosphere'
import { FloatingNodes } from '@/components/FloatingNodes'
import { CustomCursor } from '@/components/CustomCursor'
import { BootSequence } from '@/components/BootSequence'
import { Navbar } from '@/components/Navbar'
import { Hero } from '@/components/Hero'
import { Footer } from '@/components/Footer'
import { Chapter11 } from '@/sections/Chapter11/Chapter11'
import { Chapter12 } from '@/sections/Chapter12/Chapter12'
import { Chapter13 } from '@/sections/Chapter13/Chapter13'
import { Chapter14 } from '@/sections/Chapter14/Chapter14'
import { useScrollChoreography } from '@/hooks/useScrollChoreography'

export default function App() {
  const [booted, setBooted] = useState(false)

  // Lock body scroll during boot
  useEffect(() => {
    document.body.style.overflow = booted ? '' : 'hidden'
  }, [booted])

  // FIX #1: GSAP ScrollTrigger choreography — guarded + cleaned up
  useScrollChoreography(booted)

  return (
    <>
      <BootSequence onComplete={() => setBooted(true)} />
      <CustomCursor />
      <BackgroundAtmosphere />
      <FloatingNodes />

      {/* Quantum canvas — fixed background particle fluid */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <QuantumCanvas className="w-full h-full opacity-50" />
      </div>

      <div className="relative z-10">
        <Navbar />
        <main>
          <Hero />
          <Chapter11 />
          <Chapter12 />
          <Chapter13 />
          <Chapter14 />
        </main>
        <Footer />
      </div>
    </>
  )
}
