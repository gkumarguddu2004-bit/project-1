import { useEffect, useRef } from 'react'

/**
 * Tracks scroll depth (0..1 over the whole page) and normalized mouse
 * position (-1..1 on both axes). Used to drive floating 3D nodes drift.
 */
export function useParallax() {
  const scrollY = useRef(0)
  const mouse = useRef({ x: 0, y: 0 })

  useEffect(() => {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduceMotion) return

    const onScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight
      scrollY.current = max > 0 ? window.scrollY / max : 0
    }
    const onMouse = (e: MouseEvent) => {
      mouse.current = {
        x: (e.clientX / window.innerWidth) * 2 - 1,
        y: (e.clientY / window.innerHeight) * 2 - 1,
      }
    }
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    window.addEventListener('mousemove', onMouse, { passive: true })
    return () => {
      window.removeEventListener('scroll', onScroll)
      window.removeEventListener('mousemove', onMouse)
    }
  }, [])

  return { scrollY, mouse }
}
