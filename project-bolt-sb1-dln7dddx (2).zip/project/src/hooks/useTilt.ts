import { useCallback, useRef, useState } from 'react'

interface TiltOptions {
  max?: number        // max rotation in degrees
  scale?: number      // hover scale
  perspective?: number
  glare?: boolean
}

/**
 * 3D mouse-tilt hook. Attach `ref` to a preserve-3d element and call
 * `onMouseMove` / `onMouseLeave`. Returns a glare style for optional use.
 */
export function useTilt<T extends HTMLElement = HTMLDivElement>({
  max = 14,
  scale = 1.04,
  perspective = 900,
  glare = true,
}: TiltOptions = {}) {
  const ref = useRef<T>(null)
  const [glarePos, setGlarePos] = useState({ x: 50, y: 50, active: false })

  const onMouseMove = useCallback(
    (e: React.MouseEvent<T>) => {
      const el = ref.current
      if (!el) return
      const rect = el.getBoundingClientRect()
      const px = (e.clientX - rect.left) / rect.width   // 0..1
      const py = (e.clientY - rect.top) / rect.height    // 0..1
      const rotateY = (px - 0.5) * 2 * max
      const rotateX = -(py - 0.5) * 2 * max
      el.style.transform = `perspective(${perspective}px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(${scale})`
      if (glare) setGlarePos({ x: px * 100, y: py * 100, active: true })
    },
    [max, scale, perspective, glare]
  )

  const onMouseLeave = useCallback(() => {
    const el = ref.current
    if (!el) return
    el.style.transform = `perspective(${perspective}px) rotateX(0deg) rotateY(0deg) scale(1)`
    if (glare) setGlarePos((p) => ({ ...p, active: false }))
  }, [perspective, glare])

  const glareStyle: React.CSSProperties = glare
    ? {
        background: `radial-gradient(circle at ${glarePos.x}% ${glarePos.y}%, rgba(34,211,238,0.22), transparent 50%)`,
        opacity: glarePos.active ? 1 : 0,
      }
    : {}

  return { ref, onMouseMove, onMouseLeave, glareStyle }
}
