import { useEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

/**
 * useScrollChoreography — GSAP + ScrollTrigger scroll-bound choreography.
 *
 * FIX #1 applied:
 *  - `gsap.registerPlugin(ScrollTrigger)` is guarded inside useEffect with
 *    `typeof window !== 'undefined'` (prevents SSR / non-browser crash).
 *  - Cleanup kills all ScrollTrigger instances on unmount / dependency change:
 *    `return () => ScrollTrigger.getAll().forEach(t => t.kill())`.
 */
export function useScrollChoreography(active: boolean) {
  useEffect(() => {
    if (!active) return
    if (typeof window === 'undefined') return // FIX #1: SSR guard

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduceMotion) return

    gsap.registerPlugin(ScrollTrigger)

    const ctx = gsap.context(() => {
      // [data-reveal] — fade up
      gsap.utils.toArray<HTMLElement>('[data-reveal]').forEach((el) => {
        gsap.from(el, {
          opacity: 0,
          y: 40,
          duration: 0.9,
          ease: 'power3.out',
          scrollTrigger: { trigger: el, start: 'top 85%', once: true },
        })
      })

      // [data-flyin] — 3D Z-axis fly-in
      gsap.utils.toArray<HTMLElement>('[data-flyin]').forEach((el) => {
        gsap.from(el, {
          opacity: 0,
          z: -120,
          rotateX: 12,
          duration: 1.1,
          ease: 'back.out(1.4)',
          scrollTrigger: { trigger: el, start: 'top 88%', once: true },
        })
      })

      // [data-stagger] — staggered children
      gsap.utils.toArray<HTMLElement>('[data-stagger]').forEach((el) => {
        const items = el.children
        if (!items.length) return
        gsap.from(items, {
          opacity: 0,
          y: 32,
          duration: 0.7,
          ease: 'power3.out',
          stagger: 0.1,
          scrollTrigger: { trigger: el, start: 'top 85%', once: true },
        })
      })

      // [data-parallax] — scroll-bound parallax
      gsap.utils.toArray<HTMLElement>('[data-parallax]').forEach((el) => {
        const depth = parseFloat(el.dataset.parallax || '0.3')
        gsap.to(el, {
          y: () => -window.innerHeight * depth,
          ease: 'none',
          scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: 0.6 },
        })
      })
    })

    // FIX #1: cleanup — kill all ScrollTriggers + GSAP context
    return () => {
      ctx.revert()
      ScrollTrigger.getAll().forEach((t) => t.kill())
    }
  }, [active])
}
