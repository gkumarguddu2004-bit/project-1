export interface ComparisonRow { label: string; traditional: string; gkweber: string }
export const comparisonRows: ComparisonRow[] = [
  { label: 'Front-end Architecture', traditional: 'Monolithic front-end view layers', gkweber: 'Decoupled, event-driven micro-services' },
  { label: 'Data Synchronization', traditional: 'Manual CSV / API cron-job syncing', gkweber: 'Real-time Webhook & AI streaming pipelines' },
  { label: 'State Hydration', traditional: 'Client-side reactive layout updates', gkweber: 'Globally distributed edge-state hydration' },
  { label: 'Security Model', traditional: 'Perimeter-based application security', gkweber: 'Strict Zero-Trust access tokens & runtime isolation' },
  { label: 'Scaling Strategy', traditional: 'Vertical server resource sizing', gkweber: 'Horizontal, sub-second serverless auto-scaling' },
]
export interface AdvantageCard { id: string; icon: string; title: string; systemSpec: string; value: string; animation: 'neural' | 'grid' | 'ripple' | 'graph' | 'shield' | 'loop' }
export const advantageCards: AdvantageCard[] = [
  { id: 'ai-first', icon: 'neural', title: 'AI-First Native Automation', systemSpec: 'Vector Embeddings, Isolated LLM Runtimes, Async Queue Handling.', value: 'Processes unstructured data inputs without creating blocking runtime loops.', animation: 'neural' },
  { id: 'enterprise-eng', icon: 'grid', title: 'Enterprise Infrastructure Engineering', systemSpec: 'Strict Type-Safety (TypeScript 5.x), Stateless API design, Micro-frontends.', value: 'Eliminates codebase technical debt, allowing rapid feature expansion without regression.', animation: 'grid' },
  { id: 'cognitive-ux', icon: 'ripple', title: 'Cognitive-Load Optimized UX', systemSpec: "Fitts's Law structural mapping, sub-100ms interface state mutations.", value: 'Lowers operational onboarding times and minimizes data entry errors.', animation: 'ripple' },
  { id: 'edge-perf', icon: 'graph', title: 'Edge Performance Topography', systemSpec: 'Global Edge Node Deployment, Next.js PPR (Partial Prerendering).', value: 'Delivers instant interactive app shells globally, maximizing conversion funnels.', animation: 'graph' },
  { id: 'zero-trust', icon: 'shield', title: 'Hardened Zero-Trust Security', systemSpec: 'AES-256 data rest encryption, automated JWT rotation, OWASP verification.', value: 'Insulates corporate assets from exposure, passing strict enterprise procurement audits.', animation: 'shield' },
  { id: 'telemetry', icon: 'loop', title: 'Automated System Telemetry', systemSpec: 'OpenTelemetry hooks, continuous health logging, self-healing node clusters.', value: 'Automatically isolates runtime anomalies before they cause platform downtime.', animation: 'loop' },
]
export interface WorkflowVertical { id: string; label: string; legacy: string[]; optimized: string[] }
export const workflowVerticals: WorkflowVertical[] = [
  { id: 'fintech', label: 'FinTech', legacy: ['Siloed REST endpoints', 'Manual reconciliation batches', 'Overnight settlement windows'], optimized: ['Event-driven ledger streams', 'Real-time fraud inference', 'Sub-second clearing pipelines'] },
  { id: 'logistics', label: 'Logistics', legacy: ['Manual document verification', 'Blocking synchronous API chains', 'Inventory dispatch lag'], optimized: ['Parallel AI extraction workers', 'Redis cache queue fan-out', 'Automated dispatch state machine'] },
  { id: 'saas', label: 'SaaS Operations', legacy: ['Cron-based customer syncs', 'Reactive incident response', 'Rigid billing cycles'], optimized: ['Webhook-native event bus', 'Predictive anomaly detection', 'Usage-metered real-time billing'] },
]
export const enterpriseStandards = ['Accessibility Focused', 'Mobile First', 'SEO Optimized', 'Performance Optimized', 'Secure Architecture', 'Scalable Infrastructure', 'Modern Technology Stack', 'API Ready']
export const clientPromise = ['Clear communication', 'Transparent timelines', 'Collaborative planning', 'High-quality engineering', 'Long-term partnership']
export const capabilityMetrics = ['Enterprise Ready', 'AI Enabled', 'Scalable Architecture', 'Performance Focused', 'Secure Infrastructure', 'Zero-Trust Verified']
