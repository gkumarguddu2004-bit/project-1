export interface KpiCard { id: string; icon: string; title: string; metric: string; explanation: string; trend: 'up' | 'stable' | 'active' }
export const kpiCards: KpiCard[] = [
  { id: 'edge-node', icon: 'server', title: 'Edge Node Status', metric: 'ACTIVE', explanation: 'Production edge nodes online and serving hydrated shells globally.', trend: 'active' },
  { id: 'tti', icon: 'bolt', title: 'Time To Interactive', metric: '0.12s', explanation: 'Median time-to-interactive measured across global edge regions.', trend: 'up' },
  { id: 'uptime', icon: 'shield', title: 'Global Uptime Score', metric: '99.99%', explanation: 'Audited uptime across the last four operational quarters.', trend: 'stable' },
  { id: 'security', icon: 'lock', title: 'Security Handshake', metric: 'OWASP VALIDATED', explanation: 'Runtime security posture verified against OWASP Top 10 controls.', trend: 'active' },
]
export interface OutcomeCard { id: string; title: string; description: string; icon: string }
export const outcomeCards: OutcomeCard[] = [
  { id: 'efficiency', title: 'Operational Efficiency', description: 'Businesses spend less time on repetitive work through intelligent automation.', icon: 'gear' },
  { id: 'response', title: 'Faster Customer Response', description: 'AI-powered workflows improve communication speed across every touchpoint.', icon: 'wave' },
  { id: 'decisions', title: 'Better Decision Making', description: 'Real-time dashboards provide actionable business insights.', icon: 'chart' },
  { id: 'scalable', title: 'Scalable Digital Infrastructure', description: 'Systems are designed to grow alongside the organization.', icon: 'layers' },
  { id: 'productivity', title: 'Higher Productivity', description: 'Automation reduces repetitive administrative tasks.', icon: 'spark' },
  { id: 'experience', title: 'Better Customer Experience', description: 'Modern interfaces and AI support improve satisfaction.', icon: 'heart' },
]
export interface Testimonial { id: string; quote: string; name: string; role: string; company: string }
export const testimonials: Testimonial[] = [
  { id: 't1', quote: 'The architecture deployment fundamentally restructured our internal operation pipelines. Workflows that historically required hours of manual data orchestration now execute reliably via background automation frameworks.', name: 'Principal Director', role: 'Systems Infrastructure', company: 'Logistics Operations Group' },
  { id: 't2', quote: 'Processes that once required manual orchestration now run autonomously. The system telemetry gives us visibility we never had with our previous vendor.', name: 'Head of Platform', role: 'Engineering Operations', company: 'FinTech Infrastructure Group' },
  { id: 't3', quote: 'The collaboration transformed the way our team operates. Processes that once took hours are now automated, and data integrity is maintained by construction.', name: 'Operations Lead', role: 'Digital Transformation', company: 'SaaS Operations Group' },
]
export const clientLogos = ['Logistics Operations Group', 'FinTech Infrastructure Group', 'SaaS Operations Group', 'Retail Commerce Group', 'Professional Services Group', 'Sales Intelligence Group']
export const complianceBadges = ['WCAG 2.1 Accessibility Compliant', 'OWASP Top 10 Hardened', 'Mobile-First Responsive Shell', 'REST / GraphQL API Ready', 'CI/CD Automated Build', 'Type-Safe Runtime Generation']
export const roiConfig = { volume: { min: 5000, max: 500000, default: 50000, label: 'Monthly Transaction Volume' }, time: { min: 5, max: 60, default: 15, label: 'Manual Processing Time Per Unit (mins)' }, acceleration: '+840%' }
