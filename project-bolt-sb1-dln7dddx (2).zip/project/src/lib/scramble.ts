const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&*<>/\\|+='

export function createScramble(
  target: string,
  onUpdate: (value: string) => void,
  onDone?: () => void,
  duration = 900,
  interval = 32
) {
  let frame = 0
  const totalFrames = duration / interval
  let timer = 0
  const tick = () => {
    let out = ''
    let done = 0
    for (let i = 0; i < target.length; i++) {
      const ch = target[i]
      if (ch === ' ') { out += ' '; done++; continue }
      const reveal = Math.floor((frame / totalFrames) * target.length)
      if (i < reveal) { out += ch; done++ }
      else out += CHARS[Math.floor(Math.random() * CHARS.length)]
    }
    onUpdate(out)
    frame++
    if (done >= target.length) { onUpdate(target); onDone?.(); return }
    timer = window.setTimeout(tick, interval) as unknown as number
  }
  tick()
  return () => clearTimeout(timer)
}
