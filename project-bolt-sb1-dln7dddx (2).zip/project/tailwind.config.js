/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: { 950: '#04070d', 900: '#0a0f1e', 850: '#0d1424', 800: '#121b30', 700: '#1a2540', 600: '#243152', 500: '#344163', 400: '#4a5a82', 300: '#6b7a9e', 200: '#9aa8c4', 100: '#c8d2e4' },
        cyan: { DEFAULT: '#22d3ee', glow: '#67e8f9', deep: '#0891b2' },
        accent: { teal: '#2dd4bf', blue: '#3b82f6', emerald: '#10b981', amber: '#f59e0b', rose: '#f43f5e' },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Space Grotesk', 'Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      letterSpacing: { 'ultra-tight': '-0.04em', tightest: '-0.03em' },
      animation: {
        'fade-in': 'fadeIn 0.7s ease-out forwards', 'fade-up': 'fadeUp 0.7s ease-out forwards',
        'pulse-soft': 'pulseSoft 3s ease-in-out infinite', 'shimmer': 'shimmer 2.5s linear infinite',
        'float': 'float 6s ease-in-out infinite', 'grid-expand': 'gridExpand 0.6s ease-out forwards',
        'ripple': 'ripple 1.4s ease-out infinite', 'spin-slow': 'spin 12s linear infinite',
        'scan': 'scan 4s ease-in-out infinite', 'glow-pulse': 'glowPulse 2.4s ease-in-out infinite',
        'drift': 'drift 18s ease-in-out infinite', 'drift-rev': 'driftRev 22s ease-in-out infinite',
        'orb-travel': 'orbTravel 2.4s ease-in-out forwards',
      },
      keyframes: {
        fadeIn: { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        fadeUp: { '0%': { opacity: '0', transform: 'translateY(24px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        pulseSoft: { '0%,100%': { opacity: '0.5' }, '50%': { opacity: '1' } },
        shimmer: { '0%': { backgroundPosition: '-200% 0' }, '100%': { backgroundPosition: '200% 0' } },
        float: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-12px)' } },
        gridExpand: { '0%': { transform: 'scale(0.85)', opacity: '0' }, '100%': { transform: 'scale(1)', opacity: '1' } },
        ripple: { '0%': { transform: 'scale(0.8)', opacity: '0.6' }, '100%': { transform: 'scale(2.4)', opacity: '0' } },
        scan: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(100%)' } },
        glowPulse: { '0%,100%': { boxShadow: '0 0 20px rgba(34,211,238,0.15)' }, '50%': { boxShadow: '0 0 40px rgba(34,211,238,0.4)' } },
        drift: { '0%,100%': { transform: 'translate3d(0,0,0) rotate(0deg)' }, '50%': { transform: 'translate3d(20px,-30px,0) rotate(180deg)' } },
        driftRev: { '0%,100%': { transform: 'translate3d(0,0,0) rotate(0deg)' }, '50%': { transform: 'translate3d(-25px,20px,0) rotate(-180deg)' } },
        orbTravel: { '0%': { transform: 'translate3d(0,0,0) scale(0.6)', opacity: '0' }, '15%': { opacity: '1' }, '100%': { transform: 'translate3d(var(--tx,200px),var(--ty,-120px),40px) scale(1.1)', opacity: '0' } },
      },
      backdropBlur: { xs: '2px' },
    },
  },
  plugins: [],
}
